# GCS + Airflow Production Runbook

## Normal entry point

Production execution is Airflow-driven. Do not run a direct GCS CLI as the normal production path.

- `remarketing_file_watcher_dag`: scheduled every five minutes by default.
- `remarketing_processing_dag`: trigger-only and receives the exact GCS object generation from the watcher.

Both DAGs use the shared code in `include/remarketing/`.

## Bucket structure

```text
gs://<bucket>/
├── input/
└── output/YYYY-MM-DD/
    ├── input/
    └── output/
```

On successful processing the dated output folder contains the archived input, generated report, reconciliation workbook, and SUCCESS manifest.

## Authentication

Use Application Default Credentials / Workload Identity from the managed Airflow runtime. Do not use committed service-account key JSON files.

## Required GCS permissions

The Airflow workload identity needs permissions sufficient to:

- list objects under the configured prefixes;
- read exact input object generations;
- create/copy objects;
- read destination metadata for verification;
- delete the exact claimed input generation;
- write report, reconciliation, and manifest objects.

A practical custom role should include the equivalent object list/get/create/delete capabilities required by these operations. Scope permissions to the reporting bucket wherever possible.

## Safe claim/archive behavior

The processing pipeline operates on the generation observed by the watcher. Archive is implemented as:

1. conditional copy of the exact source generation;
2. verify destination metadata;
3. conditional delete of the exact source generation.

This prevents a newer upload with the same object name from being deleted accidentally.

## Duplicate behavior

Before archive/report execution the pipeline computes SHA-256 of the exact input bytes and reads prior successful manifests.

- same SHA-256 found: duplicate is skipped and the top-level duplicate object is removed with an exact-generation delete;
- different SHA-256 after same-day SUCCESS: fail with an already-processed-date error;
- prior failed run without SUCCESS manifest: retry is allowed.

## SUCCESS marker

`run_summary_YYYYMMDD.json` is written only after report generation, zero-mismatch reconciliation, and output uploads all succeed. It is always the final published object for the run.

Do not infer success merely from the existence of the archived input or report file.

## Retry guidance

### Failure before archive

The source remains under `input/`. Airflow retry can process the same exact generation if it still exists.

### Failure after archive but before SUCCESS

The dated archived input may exist but no SUCCESS manifest exists. Re-upload the same/corrected source into `input/`; the generation-safe archive logic can replace the failed archived object and retry.

### Failure during report/reconciliation upload

No SUCCESS manifest is written. Correct the infrastructure or workbook issue and retry.

### Reconciliation mismatch

Treat as a business/reporting failure. Do not manually create a SUCCESS manifest. Investigate the mismatch, correct the input/business implementation as appropriate, and rerun.

## Manual processing DAG trigger

When manually triggering `remarketing_processing_dag`, provide exact metadata, for example:

```json
{
  "bucket_name": "remarketing-prod",
  "object_name": "input/REMARKETING_ET_REPOSSESSION.xlsx",
  "generation": 1726570000000000,
  "size": 22946228,
  "detection_timestamp": "2026-09-17T02:00:00+00:00"
}
```

Never omit or guess the object generation. Obtain it from GCS object metadata.

## Monitoring

Operationally monitor:

- watcher DAG failures caused by more than one XLSX in `input/`;
- processing DAG failures;
- reconciliation mismatch errors;
- GCS precondition failures;
- absence of a SUCCESS manifest after expected processing.


## Exact-fidelity publication gate

The final workbook is built from the uploaded XLSX OOXML package. It contains six visible
analyst-facing sheets: `Pivot Pierre`, `Feuil2`, `Pivot Soraya`, `VENTES`, `Feuil3`, and `KPIs`.
`Remarketing is veryHidden`; no other worksheet is registered in the client-facing workbook.

The pipeline first creates a temporary independent calculated workbook for business validation.
That temporary artifact is not the client deliverable. After zero unexplained business mismatches,
the shared fidelity builder creates the final workbook by preserving the source OOXML parts.
`openpyxl is not used to serialize the final client workbook`.

The analyst refreshes upstream sources before upload. external links are never refreshed by the application, including SharePoint targets, `C:\Users\...` paths, Outlook-cache paths, and `W:`
drive targets stored in workbook metadata.
