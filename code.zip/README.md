# Remarketing Airflow Automation

Production Airflow + local-test project for the analyst-refreshed Remarketing/Repossessions XLSX workflow.

The automation treats the uploaded XLSX as the **only business-data runtime input** and never connects to those external files itself.

## Repository structure

```text
remarketing_airflow_automation/
├── config/
│   ├── workbook.yml
│   ├── report_template.xlsx
│   └── reference/
├── dags/
│   ├── remarketing_file_watcher_dag.py
│   └── remarketing_processing_dag.py
├── include/
│   └── remarketing/
│       ├── __init__.py
│       ├── audit.py
│       ├── calculate.py
│       ├── config.py
│       ├── errors.py
│       ├── fidelity.py
│       ├── fidelity_validate.py
│       ├── models.py
│       ├── ooxml_package.py
│       ├── normalize.py
│       ├── notify.py
│       ├── pipeline.py
│       ├── reconcile.py
│       ├── report.py
│       ├── storage.py
│       ├── validate.py
│       └── workbook.py
├── local/
│   ├── input/
│   ├── output/
│   └── run_local.py
├── tests/
├── .env
├── .gitignore
├── Dockerfile
├── pyproject.toml
├── requirements-airflow.txt
└── requirements.txt
```

## Production flow

`remarketing_file_watcher_dag` polls `gs://<bucket>/input/` every five minutes by default.

- 0 XLSX files: successful no-op.
- 1 XLSX file: trigger `remarketing_processing_dag` with bucket, object name, exact GCS generation, size, and detection timestamp.
- More than 1 XLSX file: fail because the approved business contract permits one logical client workbook per processing day.

The watcher never moves, deletes, downloads, or processes the workbook.

`remarketing_processing_dag` is trigger-only (`schedule=None`) and calls the shared pipeline. The pipeline:

1. downloads the exact observed GCS generation;
2. computes SHA-256;
3. checks prior SUCCESS manifests for duplicate bytes;
4. rejects a different input after a same-day SUCCESS;
5. generation-safely archives the input into the dated run folder;
6. validates and processes the analyst workbook;
7. generates the analyst-equivalent report;
8. generates reconciliation and requires zero unexplained mismatches;
9. uploads report and reconciliation;
10. writes `run_summary_YYYYMMDD.json` **last** as the authoritative SUCCESS marker.

## GCS layout

```text
gs://<bucket>/
├── input/
│   └── <client-file>.xlsx
└── output/
    └── <processing-date>/
        ├── input/
        │   └── <client-file>.xlsx
        └── output/
            ├── REMARKETING_REPOSSESSION_REPORT_YYYYMMDD.xlsx
            ├── reconciliation.xlsx
            └── run_summary_YYYYMMDD.json
```

The processing date controls the bucket folder/output filename. The report-as-of business date still comes from the workbook and is recorded in the SUCCESS manifest.

Canonical dated paths are `output/<processing-date>/input/` and `output/<processing-date>/output/`.

## Airflow configuration

Recommended environment variables:

```text
REMARKETING_GCS_BUCKET=<bucket-name>
REMARKETING_INPUT_PREFIX=input/
REMARKETING_OUTPUT_PREFIX=output/
REMARKETING_WATCHER_SCHEDULE=*/5 * * * *
```

The workload should authenticate to GCS with Application Default Credentials / Workload Identity. Do not package service-account key files.

Airflow core is expected to be provided by the managed Airflow runtime. Additional provider dependency:

```bash
pip install -r requirements-airflow.txt
```

Deploy/sync at minimum:

- `dags/`
- `include/`
- `config/`
- `requirements.txt`
- `requirements-airflow.txt` as required by the Airflow platform

## Local testing

Python 3.11+:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

Place one refreshed client XLSX in:

```text
local/input/
```

Run:

```bash
python local/run_local.py
```

For a deterministic test date:

```bash
python local/run_local.py --processing-date 2026-09-17
```

Or process an explicit XLSX without deleting the original source file:

```bash
python local/run_local.py --input /path/to/client.xlsx --processing-date 2026-09-17
```

Local output mirrors production:

```text
local/output/<processing-date>/
├── input/
│   └── <client-file>.xlsx
└── output/
    ├── REMARKETING_REPOSSESSION_REPORT_YYYYMMDD.xlsx
    ├── reconciliation.xlsx
    └── run_summary_YYYYMMDD.json
```

Local execution imports the same `include/remarketing/` package as Airflow and does not import Airflow or require GCS credentials.

## Idempotency and reconciliation

Duplicate prevention is content based. SHA-256 from the exact workbook bytes is compared to all prior successful manifests, so renaming the same file does not cause a second run.

A different workbook cannot overwrite an already successful processing date. A failed run has no SUCCESS manifest, so a corrected/re-uploaded workbook remains retryable.

## Production runbook

See `docs/GCS_PRODUCTION_RUNBOOK.md`.


## Exact Excel visual fidelity

The client-facing workbook exposes exactly **six visible analyst-facing sheets**:

- `Pivot Pierre`
- `Feuil2`
- `Pivot Soraya`
- `VENTES`
- `Feuil3`
- `KPIs`

`Remarketing is veryHidden` in the final workbook so the retained native pivot tables and KPI
formulas continue to reference their original source sheet. No other worksheet is registered.

The **final workbook is built from the uploaded XLSX OOXML package**. Native worksheet XML,
styles, color definitions, theme data, pivot tables, pivot caches, charts, drawings, anchors,
conditional formatting, dimensions, merged ranges, filters, and print/page settings are reused
from the analyst workbook rather than recreated from a Python color/style palette.

`openpyxl is not used to serialize the final client workbook`. It remains part of the project only
for the independent calculated workbook and reconciliation audit. The client-facing XLSX is written
through direct OOXML package preservation.

Publication requires two independent gates: **business reconciliation and visual fidelity must both
PASS**. Business reconciliation compares the independent Python calculation output with the analyst
snapshot. Visual-fidelity validation then compares retained OOXML parts and workbook structure.
The SUCCESS manifest is written only after both gates pass.

The workbook is a snapshot supplied after the analyst has refreshed its upstream data; **external links are never refreshed by the application** and are never dereferenced by Airflow, local testing,
or the shared Python pipeline.
