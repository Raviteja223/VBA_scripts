from datetime import date
from remarketing.models import ProcessingPaths, RunManifest, RunStatus


def test_processing_paths_use_processing_date():
    paths = ProcessingPaths.for_run(output_prefix='output/', processing_date=date(2026, 9, 17), source_filename='client.xlsx')
    assert paths.archived_input == 'output/2026-09-17/input/client.xlsx'
    assert paths.report == 'output/2026-09-17/output/REMARKETING_REPOSSESSION_REPORT_20260917.xlsx'
    assert paths.reconciliation == 'output/2026-09-17/output/reconciliation.xlsx'
    assert paths.manifest == 'output/2026-09-17/output/run_summary_20260917.json'


def test_success_manifest_round_trip():
    manifest = RunManifest(status=RunStatus.SUCCESS, processing_date='2026-09-17', source_file='client.xlsx', source_sha256='abc123', archived_input='output/2026-09-17/input/client.xlsx', report='output/2026-09-17/output/report.xlsx', reconciliation='output/2026-09-17/output/reconciliation.xlsx', unexplained_mismatch_count=0)
    restored = RunManifest.from_json(manifest.to_json())
    assert restored == manifest
    assert restored.is_success is True


def test_pipeline_result_exposes_both_success_verdicts():
    from remarketing.models import PipelineResult

    result = PipelineResult(
        status=RunStatus.SUCCESS,
        processing_date="2026-09-17",
        source_file="client.xlsx",
        source_sha256="abc",
        business_reconciliation="PASS",
        visual_fidelity="PASS",
    )
    payload = result.to_dict()
    assert payload["business_reconciliation"] == "PASS"
    assert payload["visual_fidelity"] == "PASS"
