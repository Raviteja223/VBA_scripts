from pathlib import Path
import pytest
from remarketing.config import load_config
from remarketing.errors import ConfigurationError


def test_load_config_reads_defaults_and_environment_override(tmp_path: Path):
    config_path = tmp_path / 'workbook.yml'
    config_path.write_text('''\nworkbook:\n  allowed_extensions: [.xlsx]\n  required_sheets: [Remarketing]\nstorage:\n  input_prefix: input/\n  output_prefix: output/\nreport:\n  filename_pattern: REMARKETING_REPOSSESSION_REPORT_{date}.xlsx\n  reconciliation_filename: reconciliation.xlsx\n  manifest_pattern: run_summary_{date}.json\nwatcher:\n  schedule: "*/5 * * * *"\n'''.strip(), encoding='utf-8')
    config = load_config(config_path=config_path, environ={'REMARKETING_GCS_BUCKET': 'prod-bucket'})
    assert config.bucket_name == 'prod-bucket'
    assert config.input_prefix == 'input/'
    assert config.output_prefix == 'output/'
    assert config.watcher_schedule == '*/5 * * * *'
    assert config.required_sheets == ('Remarketing',)


def test_load_config_rejects_missing_bucket_when_required(tmp_path: Path):
    config_path = tmp_path / 'workbook.yml'
    config_path.write_text('storage:\n  input_prefix: input/\n  output_prefix: output/\n', encoding='utf-8')
    with pytest.raises(ConfigurationError):
        load_config(config_path=config_path, environ={}, require_bucket=True)
