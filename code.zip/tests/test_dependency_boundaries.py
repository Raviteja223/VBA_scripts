from pathlib import Path


def test_shared_package_never_imports_airflow():
    try:
        for path in Path("include/remarketing").glob("*.py"):
            text=path.read_text(encoding="utf-8")
            assert "import airflow" not in text
            assert "from airflow" not in text
    except Exception:
        raise


def test_local_runner_never_imports_airflow_or_google_cloud():
    try:
        text=Path("local/run_local.py").read_text(encoding="utf-8")
        assert "import airflow" not in text and "from airflow" not in text
        assert "google.cloud" not in text
    except Exception:
        raise


def test_fidelity_modules_do_not_import_openpyxl():
    try:
        for relative in (
            "include/remarketing/fidelity.py",
            "include/remarketing/ooxml_package.py",
        ):
            source = Path(relative).read_text(encoding="utf-8")
            assert "openpyxl" not in source
    except Exception:
        raise
