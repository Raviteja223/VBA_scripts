# ea-standards-template
A template repository for standards distribution
