"""Trigger-only production processing DAG for one exact GCS object generation."""
from __future__ import annotations

import logging
import sys
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
INCLUDE_ROOT = PROJECT_ROOT / "include"
if str(INCLUDE_ROOT) not in sys.path:
    sys.path.insert(0, str(INCLUDE_ROOT))

from remarketing.config import load_config  # noqa: E402
from remarketing.errors import (  # noqa: E402
    ConfigurationError,
    ProcessingError,
    RemarketingError,
)
from remarketing.models import GCSObjectIdentity  # noqa: E402
from remarketing.pipeline import process_gcs_object  # noqa: E402

try:
    from airflow import DAG  # noqa: E402
    from airflow.operators.python import PythonOperator  # noqa: E402
except ImportError:
    DAG = None
    PythonOperator = None

LOGGER = logging.getLogger(__name__)


def resolve_processing_request(dag_run_conf: Mapping[str, object]) -> dict[str, object]:
    """Validate and normalize exact-object metadata supplied by the watcher DAG."""
    try:
        bucket_name = str(dag_run_conf.get("bucket_name", "")).strip()
        object_name = str(dag_run_conf.get("object_name", "")).strip()
        generation = dag_run_conf.get("generation")
        detected_at = str(dag_run_conf.get("detection_timestamp", "")).strip()
        size = int(dag_run_conf.get("size", 0) or 0)
        if not bucket_name or not object_name or generation is None or not detected_at:
            raise ConfigurationError(
                "Processing trigger requires bucket_name, object_name, generation, "
                "and detection_timestamp"
            )
        return {
            "bucket_name": bucket_name,
            "object_name": object_name,
            "generation": int(generation),
            "size": size,
            "detection_timestamp": detected_at,
        }
    except RemarketingError:
        raise
    except Exception as exc:
        raise ConfigurationError("Invalid processing DAG trigger configuration") from exc


def process_remarketing_workbook(request: Mapping[str, object]) -> dict[str, object]:
    """Run production processing for the exact object generation in the request."""
    try:
        config = load_config(
            overrides={"bucket_name": str(request["bucket_name"])},
            require_bucket=True,
        )
        source = GCSObjectIdentity(
            bucket_name=str(config.bucket_name),
            object_name=str(request["object_name"]),
            generation=int(request["generation"]),
            size=int(request.get("size", 0) or 0),
        )
        detected_at = datetime.fromisoformat(
            str(request["detection_timestamp"]).replace("Z", "+00:00")
        )
        return process_gcs_object(
            config=config,
            source=source,
            processing_date=detected_at.date(),
        ).to_dict()
    except RemarketingError:
        raise
    except Exception as exc:
        raise ProcessingError("Airflow remarketing processing task failed") from exc


def log_processing_result(result: Mapping[str, object]) -> None:
    """Write the small processing result metadata to the Airflow task log."""
    try:
        LOGGER.info("Remarketing processing result: %s", dict(result))
    except Exception as exc:
        raise ProcessingError("Unable to log processing result") from exc


def _resolve_from_context() -> dict[str, object]:
    try:
        from airflow.operators.python import get_current_context

        context = get_current_context()
        dag_run = context.get("dag_run")
        conf = {} if dag_run is None else (dag_run.conf or {})
        return resolve_processing_request(conf)
    except RemarketingError:
        raise
    except Exception as exc:
        raise ConfigurationError(
            "Unable to resolve processing request from Airflow context"
        ) from exc


if DAG is not None:
    try:
        with DAG(
            dag_id="remarketing_processing_dag",
            schedule=None,
            catchup=False,
            max_active_runs=1,
            start_date=datetime(2026, 1, 1, tzinfo=UTC),
            render_template_as_native_obj=True,
            tags=["remarketing", "gcs", "processing"],
        ) as dag:
            resolve_task = PythonOperator(
                task_id="resolve_processing_request",
                python_callable=_resolve_from_context,
            )
            process_task = PythonOperator(
                task_id="process_remarketing_workbook",
                python_callable=process_remarketing_workbook,
                op_args=[resolve_task.output],
            )
            log_task = PythonOperator(
                task_id="log_processing_result",
                python_callable=log_processing_result,
                op_args=[process_task.output],
            )
            resolve_task >> process_task >> log_task
    except Exception:
        raise
else:
    dag = None
