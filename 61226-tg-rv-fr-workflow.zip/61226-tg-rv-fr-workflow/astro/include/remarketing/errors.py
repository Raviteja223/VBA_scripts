"""Domain exceptions for the remarketing automation."""


class RemarketingError(Exception):
    """Base exception for application failures."""


class ConfigurationError(RemarketingError):
    """Application configuration is invalid."""


class StorageError(RemarketingError):
    """Storage operation failed."""


class InputDiscoveryError(StorageError):
    """The input location violates the one-workbook contract."""


class DuplicateInputError(RemarketingError):
    """The exact workbook bytes were already processed successfully."""


class AlreadyProcessedError(RemarketingError):
    """A different workbook already completed for the processing date."""


class WorkbookReadError(RemarketingError):
    """Workbook bytes cannot be opened or parsed."""


class WorkbookValidationError(RemarketingError):
    """Workbook does not satisfy the reporting contract."""


class ReportGenerationError(RemarketingError):
    """Analyst-equivalent report generation failed."""


class ReconciliationError(RemarketingError):
    """Generated output does not reconcile with the analyst workbook."""


class ProcessingError(RemarketingError):
    """End-to-end processing failed."""


class NotificationError(RemarketingError):
    """Notification delivery failed."""


class ManifestError(RemarketingError):
    """Run manifest is malformed."""


class PivotDefinitionError(RemarketingError):
    """Pivot metadata is missing or invalid."""


class LayoutOverflowError(RemarketingError):
    """Generated report layout exceeds supported bounds."""


# Compatibility names used by the validated calculation engine.
ReportingError = RemarketingError
WorkbookOpenError = WorkbookReadError
SchemaValidationError = WorkbookValidationError
CachedValueError = WorkbookValidationError
ReportDateError = WorkbookValidationError
GCSConfigurationError = ConfigurationError
DuplicateFileError = DuplicateInputError
AlreadyProcessedDateError = AlreadyProcessedError


class FidelityBuildError(RemarketingError):
    """Raised when an OOXML fidelity workbook cannot be built."""


class OoxmlRelationshipError(FidelityBuildError):
    """Raised when a required OOXML relationship cannot be resolved safely."""


class VisualFidelityError(RemarketingError):
    """Raised when the generated workbook fails fidelity validation."""
