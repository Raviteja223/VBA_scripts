"""File fingerprint helpers used by production idempotency checks."""

from __future__ import annotations

from datetime import UTC, date, datetime
from hashlib import sha256
from pathlib import Path

from .models import ProcessingPaths, ReconciliationSummary, RunManifest, RunStatus


def sha256_file(path: Path | str, chunk_size: int = 1024 * 1024) -> str:
    """Return a lowercase SHA-256 digest while reading in bounded chunks."""
    try:
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")

        digest = sha256()
        with Path(path).open("rb") as handle:
            for chunk in iter(lambda: handle.read(chunk_size), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except Exception:
        raise


def build_success_manifest(
    *,
    processing_date: date,
    source_file: str,
    source_sha256: str,
    paths: ProcessingPaths,
    reconciliation: ReconciliationSummary,
    business_reconciliation: str,
    visual_fidelity: str,
) -> RunManifest:
    """Build the authoritative SUCCESS manifest after reconciliation passes."""
    try:
        return RunManifest(
            status=RunStatus.SUCCESS,
            processing_date=processing_date.isoformat(),
            source_file=source_file,
            source_sha256=source_sha256,
            archived_input=paths.archived_input,
            report=paths.report,
            reconciliation=paths.reconciliation,
            unexplained_mismatch_count=reconciliation.unexplained_mismatch_count,
            completed_at_utc=datetime.now(UTC).isoformat(),
            business_reconciliation=business_reconciliation,
            visual_fidelity=visual_fidelity,
        )
    except Exception:
        raise
