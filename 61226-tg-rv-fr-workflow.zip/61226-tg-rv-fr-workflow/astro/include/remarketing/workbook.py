from __future__ import annotations


from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
import zipfile
from xml.etree import ElementTree as ET

from openpyxl.styles.numbers import BUILTIN_FORMATS

from .errors import WorkbookOpenError
from .models import CellValue, ExcelError

_MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
_NS = {"m": _MAIN_NS, "r": _REL_NS, "pr": _PKG_REL_NS}


@dataclass(frozen=True, slots=True)
class OOXMLCell:
    """Cached OOXML cell value with formula/style metadata."""

    coordinate: str
    value: CellValue
    formula: str | None
    style_id: int
    data_type: str | None


def _parse_number(raw: str) -> int | float | str:
    try:
        if not any(ch in raw for ch in ".eE"):
            return int(raw)
        return float(raw)
    except ValueError:
        return raw


class OOXMLWorkbook:
    """Read cached Excel values directly from an XLSX OOXML package."""

    def __init__(self, path: Path | str):
        try:
            self.path = Path(path)
            try:
                self._zip = zipfile.ZipFile(self.path, "r")
            except (OSError, zipfile.BadZipFile) as exc:
                raise WorkbookOpenError(f"could not open workbook '{self.path}': {exc}") from exc
            if "xl/workbook.xml" not in self._zip.namelist():
                self._zip.close()
                raise WorkbookOpenError("workbook is missing xl/workbook.xml")
            self._sheet_paths = self._load_sheet_paths()
            self._shared_strings: list[str] | None = None
            self._style_formats: list[str] | None = None
            self._sheet_cache: dict[str, ET.Element] = {}
        except Exception:
            raise

    def close(self) -> None:
        """Close the underlying XLSX ZIP package."""
        try:
            self._zip.close()
        except Exception:
            raise

    def __enter__(self) -> "OOXMLWorkbook":
        try:
            return self
        except Exception:
            raise

    def __exit__(self, *_args) -> None:
        try:
            self.close()
        except Exception:
            raise

    def _load_sheet_paths(self) -> dict[str, str]:
        try:
            workbook = ET.fromstring(self._zip.read("xl/workbook.xml"))
            rels = ET.fromstring(self._zip.read("xl/_rels/workbook.xml.rels"))
        except (KeyError, ET.ParseError) as exc:
            raise WorkbookOpenError(f"invalid workbook relationships: {exc}") from exc
        targets = {
            rel.attrib["Id"]: rel.attrib.get("Target", "")
            for rel in rels.findall("pr:Relationship", _NS)
        }
        result: dict[str, str] = {}
        sheets = workbook.find("m:sheets", _NS)
        if sheets is None:
            return result
        for sheet in sheets.findall("m:sheet", _NS):
            name = sheet.attrib["name"]
            rid = sheet.attrib.get(f"{{{_REL_NS}}}id")
            if not rid or rid not in targets:
                continue
            target = targets[rid].replace("\\", "/")
            if target.startswith("/"):
                resolved = target.lstrip("/")
            else:
                resolved = str(PurePosixPath("xl") / target)
            # Collapse simple ../ segments without using host-path semantics.
            parts: list[str] = []
            for part in PurePosixPath(resolved).parts:
                if part == "..":
                    if parts:
                        parts.pop()
                elif part not in (".", "/"):
                    parts.append(part)
            result[name] = "/".join(parts)
        return result

    def sheet_names(self) -> tuple[str, ...]:
        """Return workbook worksheet names in source order."""
        try:
            return tuple(self._sheet_paths)
        except Exception:
            raise

    def sheet_path(self, name: str) -> str:
        """Resolve a worksheet name to its OOXML package part path."""
        try:
            return self._sheet_paths[name]
        except KeyError as exc:
            raise KeyError(f"worksheet '{name}' not found") from exc

    def _sheet_root(self, name: str) -> ET.Element:
        try:
            if name not in self._sheet_cache:
                path = self.sheet_path(name)
                try:
                    self._sheet_cache[name] = ET.fromstring(self._zip.read(path))
                except (KeyError, ET.ParseError) as exc:
                    raise WorkbookOpenError(f"could not read worksheet '{name}': {exc}") from exc
            return self._sheet_cache[name]
        except Exception:
            raise

    def _load_shared_strings(self) -> list[str]:
        try:
            if self._shared_strings is not None:
                return self._shared_strings
            if "xl/sharedStrings.xml" not in self._zip.namelist():
                self._shared_strings = []
                return self._shared_strings
            root = ET.fromstring(self._zip.read("xl/sharedStrings.xml"))
            values: list[str] = []
            for si in root.findall("m:si", _NS):
                values.append("".join(t.text or "" for t in si.findall(".//m:t", _NS)))
            self._shared_strings = values
            return values
        except Exception:
            raise

    def shared_string(self, index: int) -> str:
        """Resolve a shared-string table index to its text value."""
        try:
            return self._load_shared_strings()[index]
        except Exception:
            raise

    def _parse_cell(self, element: ET.Element) -> OOXMLCell:
        try:
            coordinate = element.attrib["r"]
            data_type = element.attrib.get("t")
            style_id = int(element.attrib.get("s", "0"))
            formula_el = element.find("m:f", _NS)
            formula = formula_el.text if formula_el is not None else None
            value_el = element.find("m:v", _NS)
            raw_v = value_el.text if value_el is not None else None

            if data_type == "s" and raw_v is not None:
                value: CellValue = self.shared_string(int(raw_v))
            elif data_type == "inlineStr":
                inline = element.find("m:is", _NS)
                value = (
                    ""
                    if inline is None
                    else "".join(
                        text_node.text or ""
                        for text_node in inline.findall(".//m:t", _NS)
                    )
                )
            elif data_type == "b":
                value = raw_v == "1"
            elif data_type == "e":
                value = ExcelError(raw_v or "#ERROR!")
            elif data_type == "str":
                value = raw_v
            elif raw_v is None:
                value = None
            else:
                value = _parse_number(raw_v)
            return OOXMLCell(coordinate, value, formula, style_id, data_type)
        except Exception:
            raise

    def read_cell(self, sheet_name: str, coordinate: str) -> OOXMLCell:
        """Read one cached cell from the requested worksheet."""
        try:
            root = self._sheet_root(sheet_name)
            element = root.find(f".//m:c[@r='{coordinate}']", _NS)
            if element is None:
                return OOXMLCell(coordinate, None, None, 0, None)
            return self._parse_cell(element)
        except Exception:
            raise

    def iter_sheet_rows(
        self,
        sheet_name: str,
        *,
        min_row: int = 1,
    ) -> Iterator[tuple[OOXMLCell, ...]]:
        """Yield parsed worksheet rows starting at the requested row number."""
        try:
            root = self._sheet_root(sheet_name)
            sheet_data = root.find("m:sheetData", _NS)
            if sheet_data is None:
                return
            for row in sheet_data.findall("m:row", _NS):
                row_number = int(row.attrib.get("r", "0"))
                if row_number < min_row:
                    continue
                yield tuple(self._parse_cell(c) for c in row.findall("m:c", _NS))
        except Exception:
            raise

    def _load_style_formats(self) -> list[str]:
        try:
            if self._style_formats is not None:
                return self._style_formats
            if "xl/styles.xml" not in self._zip.namelist():
                self._style_formats = ["General"]
                return self._style_formats
            root = ET.fromstring(self._zip.read("xl/styles.xml"))
            custom: dict[int, str] = {}
            numfmts = root.find("m:numFmts", _NS)
            if numfmts is not None:
                for fmt in numfmts.findall("m:numFmt", _NS):
                    custom[int(fmt.attrib["numFmtId"])] = fmt.attrib["formatCode"]
            xfs = root.find("m:cellXfs", _NS)
            formats: list[str] = []
            if xfs is not None:
                for xf in xfs.findall("m:xf", _NS):
                    fmt_id = int(xf.attrib.get("numFmtId", "0"))
                    formats.append(custom.get(fmt_id, BUILTIN_FORMATS.get(fmt_id, "General")))
            self._style_formats = formats or ["General"]
            return self._style_formats
        except Exception:
            raise

    def style_number_format(self, style_id: int) -> str:
        """Return the number-format code for a workbook style identifier."""
        try:
            formats = self._load_style_formats()
            if 0 <= style_id < len(formats):
                return formats[style_id]
            return "General"
        except Exception:
            raise

WorkbookReader = OOXMLWorkbook
