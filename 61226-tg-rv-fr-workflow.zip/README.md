# Remarketing Airflow Automation

Production Airflow + local-test project for the analyst-refreshed Remarketing/Repossessions XLSX workflow.

The automation treats the uploaded XLSX as the only business-data runtime input and never connects to external linked files itself.

## Repository structure

```text
remarketing_airflow_automation/
├── astro/
│   ├── config/
│   │   ├── workbook.yml
│   │   ├── report_template.xlsx
│   │   └── reference/
│   │       ├── chart_definitions.json
│   │       ├── pivot_definitions.json
│   │       └── report_layout.json
│   ├── dags/
│   │   ├── remarketing_file_watcher_dag.py
│   │   └── remarketing_processing_dag.py
│   ├── include/
│   │   └── remarketing/
│   ├── requirements.txt
│   ├── requirements-airflow.txt
│   └── Dockerfile
├── local/
│   ├── input/
│   ├── output/
│   └── run_local.py
├── tests/
├── .gitignore
└── README.md
```

## Production flow

`remarketing_file_watcher_dag` polls `gs://<input-bucket>/input/` every five minutes by default.

- 0 XLSX files: successful no-op.
- 1 XLSX file: trigger `remarketing_processing_dag` with bucket, object name, exact GCS generation, size, and detection timestamp.
- More than 1 XLSX file: fail because the approved business contract permits one logical client workbook per processing day.

The watcher never moves, deletes, downloads, or processes the workbook.

`remarketing_processing_dag` is trigger-only (`schedule=None`) and calls the shared pipeline. The pipeline:

1. downloads the exact observed GCS generation from the input bucket;
2. computes SHA-256;
3. checks prior SUCCESS manifests for duplicate bytes in the output bucket;
4. rejects a different input after a same-day SUCCESS;
5. generation-safely archives the input into the dated run folder in the input bucket;
6. validates and processes the analyst workbook;
7. generates the analyst-equivalent report;
8. generates reconciliation and requires zero unexplained mismatches;
9. uploads report and reconciliation to the output bucket;
10. writes `run_summary_YYYYMMDD.json` last as the authoritative SUCCESS marker.

## GCS layout

Input bucket:

```text
gs://<input-bucket>/
├── input/
│   └── <client-file>.xlsx
└── output/
    └── <processing-date>/
        └── input/
            └── <client-file>.xlsx
```

Output bucket:

```text
gs://<output-bucket>/
└── output/
    └── <processing-date>/
        └── output/
            ├── REMARKETING_REPOSSESSION_REPORT_YYYYMMDD.xlsx
            ├── reconciliation.xlsx
            └── run_summary_YYYYMMDD.json
```

Canonical dated paths are `output/<processing-date>/input/` and `output/<processing-date>/output/`.

## Airflow configuration

Bucket configuration is hardcoded in `astro/include/remarketing/config.py`:

```text
DEFAULT_GCS_INPUT_BUCKET=<input bucket>
DEFAULT_GCS_OUTPUT_BUCKET=<output bucket>
```

The workload should authenticate to GCS with Application Default Credentials / Workload Identity. Do not package service-account key files.

Airflow core is expected to be provided by the managed Airflow runtime. Additional provider dependency is declared in `astro/requirements-airflow.txt`.

Deploy/sync at minimum:

- `astro/dags/`
- `astro/include/`
- `astro/config/`
- `astro/requirements.txt`
- `astro/requirements-airflow.txt`
- `astro/Dockerfile`

## Local testing

Python 3.11+:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r astro/requirements.txt
```

Place one refreshed client XLSX in:

```text
local/input/
```

Run:

```bash
python local/run_local.py
```

For a deterministic test date:

```bash
python local/run_local.py --processing-date 2026-09-17
```

Or process an explicit XLSX without deleting the original source file:

```bash
python local/run_local.py --input /path/to/client.xlsx --processing-date 2026-09-17
```

Local output mirrors production paths under:

```text
local/output/<processing-date>/
├── input/
│   └── <client-file>.xlsx
└── output/
    ├── REMARKETING_REPOSSESSION_REPORT_YYYYMMDD.xlsx
    ├── reconciliation.xlsx
    └── run_summary_YYYYMMDD.json
```

`local/run_local.py` imports the same `remarketing` package from `astro/include/remarketing/` and does not import Airflow.

## Idempotency and reconciliation

Duplicate prevention is content-based. SHA-256 from exact workbook bytes is compared to prior successful manifests, so renaming the same file does not cause a second run.

A different workbook cannot overwrite an already successful processing date. A failed run has no SUCCESS manifest, so a corrected re-upload remains retryable.

## Exact Excel visual fidelity

The client-facing workbook exposes exactly six visible analyst-facing sheets:

- `Pivot Pierre`
- `Feuil2`
- `Pivot Soraya`
- `VENTES`
- `Feuil3`
- `KPIs`

`Remarketing` is veryHidden in the final workbook so retained native pivot tables and KPI formulas continue to reference their original source sheet.

The final workbook is built from the uploaded XLSX OOXML package. Native worksheet XML, styles, color definitions, theme data, pivot tables, pivot caches, charts, drawings, anchors, conditional formatting, dimensions, merged ranges, filters, and print/page settings are reused from the analyst workbook rather than recreated from a Python style palette.

`openpyxl` is not used to serialize the final client workbook. It remains in the project for independent calculated workbook generation and reconciliation audit.

Publication requires two independent gates: business reconciliation and visual fidelity must both PASS. The SUCCESS manifest is written only after both gates pass.

The workbook is a snapshot supplied after the analyst has refreshed upstream data. External links are never refreshed or dereferenced by Airflow, local testing, or the shared Python pipeline.
