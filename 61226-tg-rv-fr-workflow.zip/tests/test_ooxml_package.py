from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import pytest

from remarketing.errors import OoxmlRelationshipError
from remarketing.ooxml_package import OOXMLPackage, sha256_bytes


def _write_minimal_package(path: Path) -> None:
    try:
        with ZipFile(path, "w", ZIP_DEFLATED) as archive:
            archive.writestr("xl/workbook.xml", b"<workbook/>")
            archive.writestr(
                "xl/_rels/workbook.xml.rels",
                b'''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                <Relationship Id="rId1" Type="worksheet" Target="worksheets/sheet1.xml"/>
                <Relationship Id="rId2" Type="externalLink" Target="https://example.invalid/file.xlsx" TargetMode="External"/>
                </Relationships>''',
            )
            archive.writestr("xl/worksheets/sheet1.xml", b"<worksheet/>")
            archive.writestr(
                "xl/worksheets/_rels/sheet1.xml.rels",
                b'''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                <Relationship Id="rId1" Type="drawing" Target="../drawings/drawing1.xml"/>
                </Relationships>''',
            )
            archive.writestr("xl/drawings/drawing1.xml", b"<drawing/>")
    except Exception:
        raise


def test_internal_target_is_normalized_inside_package(tmp_path):
    try:
        path = tmp_path / "sample.xlsx"
        _write_minimal_package(path)
        with OOXMLPackage(path) as package:
            relationships = package.relationships("xl/workbook.xml")
            assert package.resolve_target("xl/workbook.xml", relationships[0]) == (
                "xl/worksheets/sheet1.xml"
            )
    except Exception:
        raise


def test_external_target_is_never_resolved_or_opened(tmp_path):
    try:
        path = tmp_path / "sample.xlsx"
        _write_minimal_package(path)
        with OOXMLPackage(path) as package:
            relationships = package.relationships("xl/workbook.xml")
            assert package.resolve_target("xl/workbook.xml", relationships[1]) is None
    except Exception:
        raise


def test_worksheet_relative_target_resolves_against_source_directory(tmp_path):
    try:
        path = tmp_path / "sample.xlsx"
        _write_minimal_package(path)
        with OOXMLPackage(path) as package:
            relationship = package.relationships("xl/worksheets/sheet1.xml")[0]
            assert package.resolve_target("xl/worksheets/sheet1.xml", relationship) == (
                "xl/drawings/drawing1.xml"
            )
    except Exception:
        raise


def test_missing_part_is_wrapped(tmp_path):
    try:
        path = tmp_path / "sample.xlsx"
        _write_minimal_package(path)
        with OOXMLPackage(path) as package:
            with pytest.raises(OoxmlRelationshipError):
                package.read_part("missing.xml")
    except Exception:
        raise


def test_sha256_bytes_is_stable():
    try:
        assert sha256_bytes(b"abc") == (
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        )
    except Exception:
        raise


def test_relationship_parser_rejects_xml_entities(tmp_path):
    path = tmp_path / "malicious.xlsx"
    with ZipFile(path, "w", ZIP_DEFLATED) as archive:
        archive.writestr("xl/workbook.xml", b"<workbook/>")
        archive.writestr(
            "xl/_rels/workbook.xml.rels",
            b'<!DOCTYPE x [<!ENTITY attack "expanded">]><Relationships>&attack;</Relationships>',
        )

    with OOXMLPackage(path) as package:
        with pytest.raises(OoxmlRelationshipError):
            package.relationships("xl/workbook.xml")
