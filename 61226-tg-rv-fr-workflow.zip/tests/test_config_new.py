from pathlib import Path
import pytest
from remarketing.config import load_config
from remarketing.errors import ConfigurationError


def test_load_config_reads_hardcoded_bucket_defaults(tmp_path: Path):
    config_path = tmp_path / 'workbook.yml'
    config_path.write_text('''\nworkbook:\n  allowed_extensions: [.xlsx]\n  required_sheets: [Remarketing]\nstorage:\n  input_prefix: input/\n  output_prefix: output/\nreport:\n  filename_pattern: REMARKETING_REPOSSESSION_REPORT_{date}.xlsx\n  reconciliation_filename: reconciliation.xlsx\n  manifest_pattern: run_summary_{date}.json\nwatcher:\n  schedule: "*/5 * * * *"\n'''.strip(), encoding='utf-8')
    config = load_config(config_path=config_path)
    assert config.bucket_name == 'prj-ml-cap-rv-uk-d-tg-rv-fr-in-input'
    assert config.output_bucket_name == 'prj-ml-cap-rv-uk-d-tg-rv-fr-in-output'
    assert config.input_prefix == 'input/'
    assert config.output_prefix == 'output/'
    assert config.watcher_schedule == '*/5 * * * *'
    assert config.required_sheets == ('Remarketing',)


def test_load_config_rejects_missing_bucket_when_required(tmp_path: Path):
    config_path = tmp_path / 'workbook.yml'
    config_path.write_text('storage:\n  input_prefix: input/\n  output_prefix: output/\n', encoding='utf-8')
    config = load_config(config_path=config_path, require_bucket=True)
    assert config.bucket_name == 'prj-ml-cap-rv-uk-d-tg-rv-fr-in-input'


def test_load_config_allows_bucket_overrides_without_env(tmp_path: Path):
    config_path = tmp_path / 'workbook.yml'
    config_path.write_text('storage:\n  input_prefix: input/\n  output_prefix: output/\n', encoding='utf-8')
    config = load_config(
        config_path=config_path,
        overrides={
            'bucket_name': 'override-input',
            'output_bucket_name': 'override-output',
        },
    )
    assert config.bucket_name == 'override-input'
    assert config.output_bucket_name == 'override-output'


def test_load_config_rejects_non_yaml_path(tmp_path: Path):
    config_path = tmp_path / 'workbook.txt'
    config_path.write_text('invalid', encoding='utf-8')
    with pytest.raises(ConfigurationError):
        load_config(config_path=config_path)


def test_load_config_rejects_parent_traversal_path(tmp_path: Path):
    config_path = tmp_path / 'workbook.yml'
    config_path.write_text('storage:\n  input_prefix: input/\n', encoding='utf-8')
    traversal = Path('..') / config_path.name
    with pytest.raises(ConfigurationError):
        load_config(config_path=traversal)
