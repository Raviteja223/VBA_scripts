from remarketing.report import report_filename

def test_report_filename_is_processing_date_deterministic():
    assert report_filename('20260917') == 'REMARKETING_REPOSSESSION_REPORT_20260917.xlsx'
