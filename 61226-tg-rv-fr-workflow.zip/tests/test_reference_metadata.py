from collections import Counter

from remarketing.calculate import load_chart_definitions, load_pivot_definitions

EXPECTED_PIVOT_COUNTS = {
    "Pivot Pierre": 6,
    "Feuil2": 1,
    "Pivot Soraya": 10,
    "VENTES": 9,
    "Feuil3": 2,
}

EXPECTED_ANCHORS = {
    "Pivot Pierre": {"A46:B54", "A5:B34", "A120:B127", "A89:B97", "L43:M49", "A107:E114"},
    "Feuil2": {"A3:A12"},
    "Pivot Soraya": {"A221:K228", "A27:C33", "A169:B177", "A188:H199", "A77:H88", "A141:C145", "A47:U55", "A5:D19", "A152:A153", "A281:C285"},
    "VENTES": {"A203", "A182:I189", "A5:C14", "A165:I172", "A65:I72", "A119:Q153", "A28:I30", "A92:G96", "A40:I45"},
    "Feuil3": {"C44:J53", "C16:K25"},
}


def test_checked_in_pivot_manifest_has_all_28_pivots():
    specs = load_pivot_definitions()
    assert len(specs) == 28
    assert Counter(spec.sheet for spec in specs) == Counter(EXPECTED_PIVOT_COUNTS)
    for sheet, anchors in EXPECTED_ANCHORS.items():
        assert {s.reference_range for s in specs if s.sheet == sheet} == anchors


def test_chart_manifest_has_five_soraya_and_two_ventes_charts():
    charts = load_chart_definitions()
    assert Counter(c.sheet for c in charts) == Counter({"Pivot Soraya": 5, "VENTES": 2})


def test_all_pivots_have_stable_ids_and_preserve_label_only_pivot():
    specs = load_pivot_definitions()
    assert len({spec.pivot_id for spec in specs}) == 28
    feuil2 = next(spec for spec in specs if spec.pivot_id == "feuil2_01")
    assert feuil2.data_fields == ()


def test_percentage_data_field_metadata_is_preserved():
    spec = next(s for s in load_pivot_definitions() if s.pivot_id == "pivot_soraya_02")
    percentage = next(d for d in spec.data_fields if d.caption == "Nombre de VIN2")
    assert percentage.show_data_as == "percentOfCol"


def test_multi_data_field_column_layout_position_is_preserved():
    specs = {s.pivot_id: s for s in load_pivot_definitions()}
    assert specs["pivot_soraya_03"].data_fields_outer is True
    assert specs["pivot_pierre_05"].data_fields_outer is False


def test_hidden_items_on_inactive_fields_are_not_compiled_as_filters():
    spec = next(s for s in load_pivot_definitions() if s.pivot_id == "pivot_pierre_03")
    assert [flt.field for flt in spec.filters] == ["Restituable"]


def test_pivot_manifest_records_the_embedded_cache_definition():
    spec = next(s for s in load_pivot_definitions() if s.pivot_id == "pivot_pierre_01")
    assert spec.cache_definition == "xl/pivotCache/pivotCacheDefinition1.xml"


def test_single_row_field_order_uses_saved_row_items_display_order():
    specs = {s.pivot_id: s for s in load_pivot_definitions()}
    assert specs["pivot_pierre_02"].item_order["Dealer groupe vh restitue"][:5] == (
        "LAGASSE", "PRIOD", "COLIN", "GREGOIRE", "KARSENTY"
    )
    assert specs["pivot_pierre_04"].item_order["Dealer groupe vh restitue"][:7] == (
        "LAGASSE", "PRIOD", "GUEZ", "BOURGOIN", "#N/A", "GREGOIRE", "KARSENTY"
    )
