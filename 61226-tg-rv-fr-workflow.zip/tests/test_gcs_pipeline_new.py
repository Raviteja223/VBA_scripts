from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest

from remarketing.config import load_config
from remarketing.errors import AlreadyProcessedError, ReconciliationError
from remarketing.models import (
    GCSObjectIdentity,
    ReconciliationSummary,
    ReportArtifact,
    RunManifest,
    RunStatus,
    VisualFidelityResult,
)
from remarketing.pipeline import process_gcs_object
from remarketing.storage import GCSObjectInfo


class FakeStorage:
    def __init__(self, source_bytes: bytes = b"new-bytes"):
        self.source_bytes = source_bytes
        self.manifests: list[RunManifest] = []
        self.events: list[tuple] = []
        self.existing: dict[str, GCSObjectInfo] = {}

    def download_exact(self, source, destination):
        self.events.append(("download", source.name, source.generation))
        Path(destination).write_bytes(self.source_bytes)
        return Path(destination)

    def list_success_manifests(self, output_prefix="output/"):
        self.events.append(("list_manifests", output_prefix))
        return list(self.manifests)

    def delete_exact(self, source):
        self.events.append(("delete", source.name, source.generation))

    def archive_exact(self, source, destination_name):
        self.events.append(("archive", source.object_name, destination_name, source.generation))
        return GCSObjectIdentity(source.bucket_name, destination_name, 100, source.size)

    def exists(self, object_name):
        self.events.append(("exists", object_name))
        return self.existing.get(object_name)

    def upload_file(self, source, destination_name, *, if_generation_match):
        self.events.append(("upload_file", destination_name, if_generation_match))
        return GCSObjectInfo(destination_name, 200, Path(source).stat().st_size)

    def upload_text(self, text, destination_name, *, if_generation_match):
        self.events.append(("upload_text", destination_name, if_generation_match))
        return GCSObjectInfo(destination_name, 300, len(text))


def _config(tmp_path: Path):
    return load_config(
        overrides={
            "bucket_name": "bucket",
            "full_fidelity": False,
        },
        require_bucket=True,
    )


def _success_manifest(day: str, digest: str) -> RunManifest:
    return RunManifest(
        status=RunStatus.SUCCESS,
        processing_date=day,
        source_file="old.xlsx",
        source_sha256=digest,
        archived_input=f"output/{day}/input/old.xlsx",
        report=f"output/{day}/output/report.xlsx",
        reconciliation=f"output/{day}/output/reconciliation.xlsx",
        unexplained_mismatch_count=0,
    )


def test_duplicate_bytes_are_skipped_before_archive(tmp_path, monkeypatch):
    import remarketing.pipeline as module

    storage = FakeStorage(b"same")
    source_file = tmp_path / "same.xlsx"
    source_file.write_bytes(b"same")
    digest = module.sha256_file(source_file)
    storage.manifests = [_success_manifest("2026-09-16", digest)]
    source = GCSObjectIdentity("bucket", "input/renamed.xlsx", 42, 4)

    result = process_gcs_object(
        config=_config(tmp_path),
        source=source,
        storage=storage,
        processing_date=date(2026, 9, 17),
    )

    assert result.status == RunStatus.DUPLICATE_SKIPPED
    assert not any(event[0] == "archive" for event in storage.events)
    assert ("delete", "input/renamed.xlsx", 42) in storage.events


def test_different_input_after_same_day_success_is_rejected(tmp_path):
    storage = FakeStorage(b"different")
    storage.manifests = [_success_manifest("2026-09-17", "old-hash")]
    source = GCSObjectIdentity("bucket", "input/client.xlsx", 43, 9)

    with pytest.raises(AlreadyProcessedError):
        process_gcs_object(
            config=_config(tmp_path),
            source=source,
            storage=storage,
            processing_date=date(2026, 9, 17),
        )

    assert not any(event[0] == "archive" for event in storage.events)


def test_success_manifest_is_published_last(tmp_path, monkeypatch):
    import remarketing.pipeline as module

    storage = FakeStorage(b"new")
    source = GCSObjectIdentity("bucket", "input/client.xlsx", 44, 3)

    def fake_execute(*, input_path, workspace, config, processing_date):
        try:
            workspace.mkdir(parents=True, exist_ok=True)
            report = workspace / "report.xlsx"
            reconciliation = workspace / "reconciliation.xlsx"
            report.write_bytes(b"report")
            reconciliation.write_bytes(b"reco")
            return (
                ReportArtifact(
                    path=report,
                    pivot_count=28,
                    chart_count=7,
                    report_as_of_date="2026-09-16",
                ),
                ReconciliationSummary(0, 0, str(reconciliation)),
                reconciliation,
                VisualFidelityResult("PASS", ()),
            )
        except Exception:
            raise

    monkeypatch.setattr(module, "_execute_reporting", fake_execute)
    result = process_gcs_object(
        config=_config(tmp_path),
        source=source,
        storage=storage,
        processing_date=date(2026, 9, 17),
    )

    publish_events = [event for event in storage.events if event[0].startswith("upload_")]
    assert publish_events[-1][0] == "upload_text"
    assert publish_events[-1][1].endswith("run_summary_20260917.json")
    assert result.pivot_count == 28
    assert result.chart_count == 7
    assert result.mismatch_count == 0


def test_partial_outputs_are_replaced_with_generation_preconditions(tmp_path, monkeypatch):
    import remarketing.pipeline as module

    storage = FakeStorage(b"new")
    source = GCSObjectIdentity("bucket", "input/client.xlsx", 45, 3)
    report_name = "output/2026-09-17/output/REMARKETING_REPOSSESSION_REPORT_20260917.xlsx"
    reco_name = "output/2026-09-17/output/reconciliation.xlsx"
    storage.existing[report_name] = GCSObjectInfo(report_name, 701, 1)
    storage.existing[reco_name] = GCSObjectInfo(reco_name, 702, 1)

    def fake_execute(*, input_path, workspace, config, processing_date):
        try:
            workspace.mkdir(parents=True, exist_ok=True)
            report = workspace / "report.xlsx"
            reconciliation = workspace / "reconciliation.xlsx"
            report.write_bytes(b"report")
            reconciliation.write_bytes(b"reco")
            return (
                ReportArtifact(report, 28, 7, (), "2026-09-16"),
                ReconciliationSummary(0, 0, str(reconciliation)),
                reconciliation,
                VisualFidelityResult("PASS", ()),
            )
        except Exception:
            raise

    monkeypatch.setattr(module, "_execute_reporting", fake_execute)
    process_gcs_object(
        config=_config(tmp_path),
        source=source,
        storage=storage,
        processing_date=date(2026, 9, 17),
    )

    assert ("upload_file", report_name, 701) in storage.events
    assert ("upload_file", reco_name, 702) in storage.events


def test_reconciliation_failure_never_writes_success_manifest(tmp_path, monkeypatch):
    import remarketing.pipeline as module

    storage = FakeStorage(b"bad")
    source = GCSObjectIdentity("bucket", "input/client.xlsx", 46, 3)

    def fail_execute(*, input_path, workspace, config, processing_date):
        try:
            raise ReconciliationError("mismatch")
        except ReconciliationError:
            raise
        except Exception:
            raise

    monkeypatch.setattr(module, "_execute_reporting", fail_execute)
    with pytest.raises(ReconciliationError):
        process_gcs_object(
            config=_config(tmp_path),
            source=source,
            storage=storage,
            processing_date=date(2026, 9, 17),
        )

    assert not any(event[0] == "upload_text" for event in storage.events)


def test_retry_after_archive_reuses_archived_input_when_source_is_gone(tmp_path, monkeypatch):
    import remarketing.pipeline as module
    from remarketing.errors import StorageError

    archived_name = "output/2026-09-17/input/client.xlsx"

    class RetryStorage(FakeStorage):
        def __init__(self):
            super().__init__(b"archived-bytes")
            self.existing[archived_name] = GCSObjectInfo(archived_name, 900, 14)

        def download_exact(self, source, destination):
            self.events.append(("download", source.name, source.generation))
            if source.name == "input/client.xlsx":
                raise StorageError("source generation no longer exists")
            Path(destination).write_bytes(self.source_bytes)
            return Path(destination)

    storage = RetryStorage()
    source = GCSObjectIdentity("bucket", "input/client.xlsx", 50, 14)

    def fake_execute(*, input_path, workspace, config, processing_date):
        workspace.mkdir(parents=True, exist_ok=True)
        report = workspace / "report.xlsx"
        reconciliation = workspace / "reconciliation.xlsx"
        report.write_bytes(b"report")
        reconciliation.write_bytes(b"reco")
        return (
            ReportArtifact(report, 28, 7, (), "2026-09-16"),
            ReconciliationSummary(0, 0, str(reconciliation)),
            reconciliation,
            VisualFidelityResult("PASS", ()),
        )

    monkeypatch.setattr(module, "_execute_reporting", fake_execute)

    result = process_gcs_object(
        config=_config(tmp_path),
        source=source,
        storage=storage,
        processing_date=date(2026, 9, 17),
    )

    assert result.status == RunStatus.SUCCESS
    assert ("download", "input/client.xlsx", 50) in storage.events
    assert ("download", archived_name, 900) in storage.events
    assert not any(event[0] == "archive" for event in storage.events)


def test_duplicate_retry_from_archive_does_not_delete_missing_top_level_source(tmp_path):
    import remarketing.pipeline as module
    from remarketing.errors import StorageError

    archived_name = "output/2026-09-17/input/client.xlsx"

    class RetryStorage(FakeStorage):
        def __init__(self):
            super().__init__(b"same")
            self.existing[archived_name] = GCSObjectInfo(archived_name, 901, 4)

        def download_exact(self, source, destination):
            self.events.append(("download", source.name, source.generation))
            if source.name == "input/client.xlsx":
                raise StorageError("source generation no longer exists")
            Path(destination).write_bytes(self.source_bytes)
            return Path(destination)

    storage = RetryStorage()
    digest_file = tmp_path / "digest.xlsx"
    digest_file.write_bytes(b"same")
    storage.manifests = [_success_manifest("2026-09-17", module.sha256_file(digest_file))]
    source = GCSObjectIdentity("bucket", "input/client.xlsx", 51, 4)

    result = process_gcs_object(
        config=_config(tmp_path),
        source=source,
        storage=storage,
        processing_date=date(2026, 9, 17),
    )

    assert result.status == RunStatus.DUPLICATE_SKIPPED
    assert not any(event[0] == "delete" for event in storage.events)
