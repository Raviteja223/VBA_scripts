from __future__ import annotations

from datetime import date, datetime
import math
import os
from pathlib import Path

import pytest
from openpyxl.styles.numbers import is_date_format
from openpyxl.utils.cell import coordinate_to_tuple, range_boundaries
from openpyxl.utils.datetime import from_excel

from remarketing.models import ExcelError
from remarketing.workbook import OOXMLWorkbook
from remarketing.calculate import load_pivot_definitions

REFERENCE = Path(os.environ.get("REFERENCE_WORKBOOK", "/mnt/data/REMARKETING_ET_REPOSSESSION_copy24072026.xlsx"))


def _canonical(value, *, number_format: str | None = None):
    if isinstance(value, ExcelError):
        return ("error", value.code)
    if value is None or value == "":
        return None
    if isinstance(value, (date, datetime)):
        return value.date().isoformat() if isinstance(value, datetime) else value.isoformat()
    if isinstance(value, (int, float)) and number_format and is_date_format(number_format):
        converted = from_excel(value)
        return converted.date().isoformat() if isinstance(converted, datetime) else converted.isoformat()
    if isinstance(value, str):
        text = value.rstrip()
        aliases = {
            "(vide)": "(blank)",
            "Grand Total": "Total général",
            "Row Labels": "Étiquettes de lignes",
        }
        return aliases.get(text, text)
    if isinstance(value, (int, float)):
        return float(value)
    return value


def _saved_block(book: OOXMLWorkbook, sheet: str, ref: str):
    min_col, min_row, max_col, max_row = range_boundaries(ref)
    values = {(r, c): (None, None) for r in range(min_row, max_row + 1) for c in range(min_col, max_col + 1)}
    for row in book.iter_sheet_rows(sheet, min_row=min_row):
        for cell in row:
            rr, cc = coordinate_to_tuple(cell.coordinate)
            if min_row <= rr <= max_row and min_col <= cc <= max_col:
                values[(rr, cc)] = (cell.value, book.style_number_format(cell.style_id))
    return [
        [values[(r, c)] for c in range(min_col, max_col + 1)]
        for r in range(min_row, max_row + 1)
    ]


def _assert_matrix_matches_saved(result, saved):
    assert len(result.matrix) == len(saved)
    assert max((len(r) for r in result.matrix), default=0) == len(saved[0])
    for r_idx, generated_row in enumerate(result.matrix):
        for c_idx, generated in enumerate(generated_row):
            saved_value, saved_fmt = saved[r_idx][c_idx]
            left = _canonical(generated)
            right = _canonical(saved_value, number_format=saved_fmt)
            if isinstance(left, float) and isinstance(right, float):
                assert math.isclose(left, right, rel_tol=1e-9, abs_tol=1e-9), (r_idx, c_idx, left, right)
            else:
                assert left == right, (r_idx, c_idx, left, right)


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_pivot_pierre_results_reconcile_to_analyst_saved_blocks():
    from remarketing.pipeline import build_pivot_results

    specs = [s for s in load_pivot_definitions() if s.sheet == "Pivot Pierre"]
    results = build_pivot_results(REFERENCE, specs)
    assert len(results) == 6

    with OOXMLWorkbook(REFERENCE) as book:
        for spec in specs:
            _assert_matrix_matches_saved(results[spec.pivot_id], _saved_block(book, spec.sheet, spec.reference_range))


@pytest.mark.skipif(not REFERENCE.exists(), reason="reference client workbook is not available")
def test_pivot_pierre_can_be_rendered_end_to_end(tmp_path):
    from openpyxl import load_workbook
    from remarketing.pipeline import generate_pivot_report

    template = Path("config/report_template.xlsx")
    output = generate_pivot_report(
        REFERENCE,
        template,
        tmp_path / "pivot-pierre.xlsx",
        sheets={"Pivot Pierre"},
    )
    wb = load_workbook(output, data_only=True, keep_links=False)
    try:
        ws = wb["Pivot Pierre"]
        assert ws["A5"].value == "Étiquettes de lignes"
        assert ws["B34"].value == 241
        assert ws["L44"].value == "LAGASSE"
        assert ws["B54"].value == 921
        assert ws["B97"].value == 39
        assert ws["E114"].value == 128
        assert ws["B127"].value == 680
    finally:
        wb.close()


def test_generate_creates_report_and_summary_from_real_fixture_when_available(tmp_path):
    if not REFERENCE.exists():
        pytest.skip("reference client workbook is not available")
    from remarketing.models import RunConfig
    from remarketing.pipeline import generate

    result = generate(RunConfig.from_values(
        input_path=REFERENCE,
        output_dir=tmp_path,
        as_of_date=date(2026, 9, 16),
        use_system_date=False,
        full_fidelity=False,
    ))
    assert result.report_path.exists()
    assert result.summary_path.exists()
    assert result.reconciliation_path is not None
    assert result.reconciliation_path.exists()


def test_validate_creates_reconciliation_from_real_fixture_when_available(tmp_path):
    if not REFERENCE.exists():
        pytest.skip("reference client workbook is not available")
    from remarketing.models import RunConfig
    from remarketing.pipeline import validate

    result = validate(RunConfig.from_values(
        input_path=REFERENCE,
        output_dir=tmp_path,
        as_of_date=date(2026, 9, 16),
        use_system_date=False,
        full_fidelity=False,
    ))
    assert result.report_path.exists()
    assert result.reconciliation_path is not None and result.reconciliation_path.exists()
    assert result.summary_path.exists()
