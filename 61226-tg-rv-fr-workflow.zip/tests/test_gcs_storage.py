from __future__ import annotations

from pathlib import Path

import pytest

from remarketing.errors import GCSConfigurationError, StorageError
from remarketing.storage import GCSObjectInfo, GCSStorage


class FakeBlob:
    def __init__(self, name: str, generation: int = 1, data: bytes = b""):
        self.name = name
        self.generation = generation
        self.size = len(data)
        self.data = data
        self.delete_calls: list[dict[str, int]] = []
        self.download_calls: list[dict[str, int]] = []
        self.upload_calls: list[dict[str, object]] = []
        self.reload_calls = 0
        self.raise_on_download = False

    def download_to_filename(self, filename: str, **kwargs):
        if self.raise_on_download:
            raise RuntimeError("download failed")
        self.download_calls.append(kwargs)
        Path(filename).write_bytes(self.data)

    def download_as_text(self, **kwargs):
        self.download_calls.append(kwargs)
        return self.data.decode("utf-8")

    def delete(self, **kwargs):
        self.delete_calls.append(kwargs)

    def upload_from_filename(self, filename: str, **kwargs):
        self.upload_calls.append({"kind": "file", **kwargs})
        self.data = Path(filename).read_bytes()
        self.size = len(self.data)
        self.generation += 1

    def upload_from_string(self, text: str, **kwargs):
        self.upload_calls.append({"kind": "text", **kwargs})
        self.data = text.encode("utf-8")
        self.size = len(self.data)
        self.generation += 1

    def reload(self):
        self.reload_calls += 1


class FakeBucket:
    def __init__(self, blobs: list[FakeBlob] | None = None):
        self.blobs = {blob.name: blob for blob in blobs or []}
        self.copy_calls: list[dict[str, object]] = []

    def blob(self, name: str):
        return self.blobs.setdefault(name, FakeBlob(name, generation=0))

    def copy_blob(self, source_blob, destination_bucket, new_name: str, **kwargs):
        self.copy_calls.append(
            {
                "source": source_blob.name,
                "new_name": new_name,
                **kwargs,
            }
        )
        if kwargs.get("if_source_generation_match") != source_blob.generation:
            raise RuntimeError("stale source generation")
        destination = self.blobs.get(new_name)
        expected = kwargs.get("if_generation_match")
        observed = 0 if destination is None else destination.generation
        if expected is not None and expected != observed:
            raise RuntimeError("destination generation mismatch")
        copied = FakeBlob(new_name, generation=source_blob.generation + 100, data=source_blob.data)
        self.blobs[new_name] = copied
        return copied


class FakeClient:
    def __init__(self, bucket: FakeBucket):
        self.fake_bucket = bucket
        self.list_calls: list[dict[str, object]] = []

    def bucket(self, name: str):
        return self.fake_bucket

    def list_blobs(self, bucket, prefix: str):
        self.list_calls.append({"bucket": bucket, "prefix": prefix})
        return [blob for name, blob in self.fake_bucket.blobs.items() if name.startswith(prefix)]


def _storage(blobs: list[FakeBlob] | None = None):
    bucket = FakeBucket(blobs)
    return GCSStorage("remarketing-prod", client=FakeClient(bucket)), bucket


def test_constructor_rejects_blank_bucket_name():
    with pytest.raises(GCSConfigurationError, match="bucket name is required"):
        GCSStorage(" ", client=FakeClient(FakeBucket()))


def test_list_xlsx_candidates_ignores_non_xlsx_objects():
    storage, _ = _storage(
        [
            FakeBlob("input/client.xlsx", 7, b"xlsx"),
            FakeBlob("input/readme.txt", 8, b"text"),
            FakeBlob("input/nested/other.xlsx", 9, b"nested"),
            FakeBlob("input/folder/", 10, b""),
        ]
    )

    items = storage.list_xlsx_candidates("input/")

    assert [item.name for item in items] == ["input/client.xlsx"]
    assert items[0].generation == 7
    assert items[0].size == 4


def test_list_xlsx_objects_returns_recursive_xlsx_objects_sorted():
    storage, _ = _storage(
        [
            FakeBlob("output/2026-09-17/input/z.xlsx", 2, b"z"),
            FakeBlob("output/2026-09-17/input/a.xlsx", 3, b"a"),
            FakeBlob("output/2026-09-17/input/readme.txt", 4, b"t"),
        ]
    )

    assert [item.name for item in storage.list_xlsx_objects("output/2026-09-17/input/")] == [
        "output/2026-09-17/input/a.xlsx",
        "output/2026-09-17/input/z.xlsx",
    ]


def test_delete_exact_passes_generation_precondition():
    blob = FakeBlob("input/client.xlsx", 99, b"data")
    storage, _ = _storage([blob])

    storage.delete_exact(GCSObjectInfo("input/client.xlsx", 99, 4))

    assert blob.delete_calls == [{"if_generation_match": 99}]


def test_copy_exact_requires_source_and_destination_preconditions():
    blob = FakeBlob("input/client.xlsx", 99, b"data")
    storage, bucket = _storage([blob])
    source = GCSObjectInfo("input/client.xlsx", 99, 4)

    copied = storage.copy_exact(
        source,
        "output/2026-09-17/input/client.xlsx",
        destination_generation=0,
    )

    assert bucket.copy_calls[0]["if_source_generation_match"] == 99
    assert bucket.copy_calls[0]["if_generation_match"] == 0
    assert copied.name == "output/2026-09-17/input/client.xlsx"
    assert copied.size == 4


def test_download_exact_passes_generation_precondition(tmp_path):
    blob = FakeBlob("input/client.xlsx", 55, b"payload")
    storage, _ = _storage([blob])
    destination = tmp_path / "client.xlsx"

    storage.download_exact(GCSObjectInfo(blob.name, 55, 7), destination)

    assert destination.read_bytes() == b"payload"
    assert blob.download_calls == [{"if_generation_match": 55}]


def test_download_exact_wraps_sdk_failure_with_object_name(tmp_path):
    blob = FakeBlob("input/client.xlsx", 55, b"payload")
    blob.raise_on_download = True
    storage, _ = _storage([blob])

    with pytest.raises(StorageError, match="input/client.xlsx"):
        storage.download_exact(GCSObjectInfo(blob.name, 55, 7), tmp_path / "client.xlsx")


def test_upload_helpers_pass_generation_preconditions(tmp_path):
    storage, bucket = _storage()
    local = tmp_path / "report.xlsx"
    local.write_bytes(b"report")

    file_info = storage.upload_file(local, "output/report.xlsx", if_generation_match=0)
    text_info = storage.upload_text("{}\n", "output/run_summary.json", if_generation_match=0)

    assert bucket.blobs["output/report.xlsx"].upload_calls[0]["if_generation_match"] == 0
    assert bucket.blobs["output/run_summary.json"].upload_calls[0]["if_generation_match"] == 0
    assert file_info.size == 6
    assert text_info.size == 3


def test_read_text_uses_exact_generation():
    blob = FakeBlob("output/run_summary.json", 12, b'{"status":"SUCCESS"}')
    storage, _ = _storage([blob])

    text = storage.read_text(GCSObjectInfo(blob.name, 12, blob.size))

    assert text == '{"status":"SUCCESS"}'
    assert blob.download_calls == [{"if_generation_match": 12}]


def test_exists_returns_object_info_or_none():
    blob = FakeBlob("output/report.xlsx", 12, b"report")
    storage, _ = _storage([blob])

    assert storage.exists("output/report.xlsx") == GCSObjectInfo("output/report.xlsx", 12, 6)
    assert storage.exists("output/missing.xlsx") is None


def test_list_manifest_objects_matches_dated_success_manifest_names_only():
    storage, _ = _storage(
        [
            FakeBlob("output/2026-09-17/output/run_summary_20260917.json", 1, b"{}"),
            FakeBlob("output/2026-09-17/output/reconciliation.xlsx", 2, b"x"),
            FakeBlob("output/run_summary_20260917.json", 3, b"{}"),
        ]
    )

    assert [item.name for item in storage.list_manifest_objects("output/")] == [
        "output/2026-09-17/output/run_summary_20260917.json"
    ]


def test_list_success_manifests_fails_closed_on_malformed_manifest():
    from remarketing.errors import ManifestError

    storage, _ = _storage(
        [
            FakeBlob(
                "output/2026-09-17/output/run_summary_20260917.json",
                1,
                b"not-json",
            )
        ]
    )

    with pytest.raises(ManifestError):
        storage.list_success_manifests("output/")
