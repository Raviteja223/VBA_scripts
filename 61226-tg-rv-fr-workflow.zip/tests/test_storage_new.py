from pathlib import Path
import pytest
from remarketing.errors import InputDiscoveryError, StorageError
from remarketing.storage import LocalStorage


def test_local_storage_rejects_multiple_input_workbooks(tmp_path: Path):
    input_dir=tmp_path/'input'; input_dir.mkdir(); (input_dir/'a.xlsx').write_bytes(b'a'); (input_dir/'b.xlsx').write_bytes(b'b')
    storage=LocalStorage(input_dir=input_dir, output_root=tmp_path/'output')
    with pytest.raises(InputDiscoveryError): storage.resolve_single_input()


def test_local_success_manifest_scan_fails_closed_on_malformed_manifest(tmp_path: Path):
    from remarketing.errors import ManifestError

    output_root = tmp_path / "output"
    manifest = output_root / "2026-09-17" / "output" / "run_summary_20260917.json"
    manifest.parent.mkdir(parents=True)
    manifest.write_text("not-json", encoding="utf-8")
    storage = LocalStorage(input_dir=tmp_path / "input", output_root=output_root)

    with pytest.raises(ManifestError):
        storage.list_success_manifests()


def test_publish_file_rejects_parent_traversal_destination(tmp_path: Path):
    source = tmp_path / "generated.txt"
    source.write_text("ok", encoding="utf-8")
    storage = LocalStorage(input_dir=tmp_path / "input", output_root=tmp_path / "output")

    with pytest.raises(StorageError):
        storage.publish_file(source, "../escape.txt")


def test_publish_text_rejects_absolute_destination(tmp_path: Path):
    storage = LocalStorage(input_dir=tmp_path / "input", output_root=tmp_path / "output")
    absolute = str((tmp_path / "outside.txt").resolve())

    with pytest.raises(StorageError):
        storage.publish_text("x", absolute)
