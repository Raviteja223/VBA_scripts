from __future__ import annotations

from datetime import date
from types import SimpleNamespace

import pytest

from remarketing.errors import ReportDateError, SchemaValidationError
from remarketing.validate import inspect_workbook
from remarketing.models import ExcelError
from remarketing.workbook import OOXMLCell
from remarketing.validate import REPORT_CRITICAL_FIELDS, REQUIRED_SHEETS


class FakeBook:
    def __init__(self):
        self._sheet_names = tuple(REQUIRED_SHEETS)
        self.headers = list(REPORT_CRITICAL_FIELDS)
        self.kpi_cell = OOXMLCell("C2", date(2026, 7, 24), "TODAY()", 0, None)
        self.data_rows = []

    def sheet_names(self):
        return self._sheet_names

    def set_header_row(self, headers):
        self.headers = list(headers)

    def set_kpi_cell(self, coordinate, formula, value):
        assert coordinate == "C2"
        self.kpi_cell = OOXMLCell(coordinate, value, formula, 0, None)

    def iter_sheet_rows(self, sheet_name, *, min_row=1):
        if sheet_name != "Remarketing":
            return iter(())
        header = tuple(
            OOXMLCell(f"{_col(i)}1", value, None, 0, "inlineStr")
            for i, value in enumerate(self.headers, 1)
        )
        rows = [header]
        rows.extend(self.data_rows)
        return iter(rows)

    def read_cell(self, sheet_name, coordinate):
        if sheet_name == "KPIs" and coordinate == "C2":
            return self.kpi_cell
        return OOXMLCell(coordinate, None, None, 0, None)

    def style_number_format(self, style_id):
        return "General"


def _col(n):
    out = ""
    while n:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


@pytest.fixture
def fake_book():
    return FakeBook()


def test_missing_remarketing_sheet_is_fatal(fake_book):
    fake_book._sheet_names = ("KPIs",)
    with pytest.raises(SchemaValidationError, match="Remarketing"):
        inspect_workbook(fake_book)


def test_headers_are_trimmed_for_lookup_but_original_caption_is_retained(fake_book):
    fake_book.set_header_row(["Contrat ", "VIN", "Statut ", "Model "])
    inspection = inspect_workbook(fake_book, required_fields={"Contrat", "VIN", "Statut", "Model"})
    assert inspection.column_by_field["Contrat"] == "A"
    assert inspection.original_header_by_field["Contrat"] == "Contrat "


def test_explicit_date_overrides_cached_today(fake_book):
    fake_book.set_kpi_cell("C2", formula="TODAY()", value=date(2026, 7, 24))
    inspection = inspect_workbook(fake_book, explicit_as_of=date(2026, 9, 16))
    assert inspection.report_as_of_date == date(2026, 9, 16)


def test_cached_kpi_today_is_default(fake_book):
    fake_book.set_kpi_cell("C2", formula="TODAY()", value=date(2026, 7, 24))
    assert inspect_workbook(fake_book).report_as_of_date == date(2026, 7, 24)


def test_system_date_requires_explicit_opt_in(fake_book, monkeypatch):
    fake_book.set_kpi_cell("C2", formula="TODAY()", value=None)
    with pytest.raises(ReportDateError):
        inspect_workbook(fake_book)
    monkeypatch.setattr("remarketing.validate.date", SimpleNamespace(today=lambda: date(2026, 9, 17)))
    assert inspect_workbook(fake_book, use_system_date=True).report_as_of_date == date(2026, 9, 17)


def test_missing_required_header_is_actionable(fake_book):
    fake_book.set_header_row(["VIN"])
    with pytest.raises(SchemaValidationError, match="Contrat"):
        inspect_workbook(fake_book, required_fields={"VIN", "Contrat"})


def test_critical_errors_are_collected(fake_book):
    fake_book.set_header_row(["Contrat", "VIN"])
    fake_book.data_rows = [
        (
            OOXMLCell("A2", ExcelError("#N/A"), None, 0, "e"),
            OOXMLCell("B2", "VIN123", None, 0, "inlineStr"),
        )
    ]
    inspection = inspect_workbook(fake_book, required_fields={"Contrat", "VIN"})
    assert inspection.critical_errors == [("Remarketing", "A2", ExcelError("#N/A"))]


def test_duplicate_noncritical_header_is_warned_and_first_column_is_used(fake_book):
    fake_book.set_header_row(["Contrat", "VIN", "Commentaire", "Commentaire"])
    inspection = inspect_workbook(fake_book, required_fields={"Contrat", "VIN"})
    assert inspection.column_by_field["Commentaire"] == "C"
    assert any("duplicate" in warning and "Commentaire" in warning for warning in inspection.warnings)
