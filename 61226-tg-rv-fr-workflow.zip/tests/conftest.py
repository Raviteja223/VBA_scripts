from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASTRO_ROOT = ROOT / "astro"
ASTRO_INCLUDE_ROOT = ASTRO_ROOT / "include"

for candidate in (ASTRO_ROOT, ASTRO_INCLUDE_ROOT):
    text = str(candidate)
    if text not in sys.path:
        sys.path.insert(0, text)
