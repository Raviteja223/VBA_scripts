from hashlib import sha256

import pytest

from remarketing.audit import sha256_file


def test_sha256_file_matches_known_digest(tmp_path):
    path = tmp_path / "client.xlsx"
    payload = b"remarketing-client-workbook"
    path.write_bytes(payload)
    assert sha256_file(path, chunk_size=5) == sha256(payload).hexdigest()


def test_sha256_file_rejects_non_positive_chunk_size(tmp_path):
    path = tmp_path / "client.xlsx"
    path.write_bytes(b"data")
    with pytest.raises(ValueError, match="chunk_size must be positive"):
        sha256_file(path, chunk_size=0)
