from __future__ import annotations

import ast
from pathlib import Path

PRODUCTION_PATHS = [
    Path("astro/include/remarketing"),
    Path("astro/dags"),
    Path("local/run_local.py"),
]


def _iter_source_files():
    try:
        for root in PRODUCTION_PATHS:
            if root.is_file():
                yield root
            elif root.exists():
                yield from sorted(root.rglob("*.py"))
    except Exception:
        raise


def _executable_body(node):
    try:
        body = list(node.body)
        if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
            body = body[1:]
        return body
    except Exception:
        raise


def test_every_production_function_has_explicit_try_except():
    try:
        missing=[]
        for path in _iter_source_files():
            tree=ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    continue
                body=_executable_body(node)
                has_try=bool(body) and isinstance(body[0],ast.Try) and bool(body[0].handlers)
                if not has_try:
                    missing.append(f"{path}:{node.lineno}:{node.name}")
        assert not missing, "Functions missing leading try/except:\n"+"\n".join(missing)
    except Exception:
        raise


def test_no_bare_except_or_silent_exception_pass():
    try:
        violations=[]
        for path in _iter_source_files():
            tree=ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node,ast.ExceptHandler) and node.type is None:
                    violations.append(f"{path}:{node.lineno}:bare-except")
                if isinstance(node,ast.ExceptHandler) and isinstance(node.type,ast.Name) and node.type.id=="Exception" and len(node.body)==1 and isinstance(node.body[0],ast.Pass):
                    violations.append(f"{path}:{node.lineno}:exception-pass")
        assert not violations, "Invalid exception handlers:\n"+"\n".join(violations)
    except Exception:
        raise


def test_production_source_lines_respect_black_line_length():
    try:
        violations = []
        for path in _iter_source_files():
            for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                if len(line) > 100:
                    violations.append(f"{path}:{line_number}:{len(line)}")
        assert not violations, "Production lines over 100 characters:\n" + "\n".join(violations)
    except Exception:
        raise


def test_public_production_interfaces_have_docstrings_and_type_hints():
    try:
        violations = []
        for path in _iter_source_files():
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef) and not node.name.startswith("_"):
                    if ast.get_docstring(node) is None:
                        violations.append(f"{path}:{node.lineno}:{node.name}:class-docstring")
                if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                if node.name.startswith("_"):
                    continue
                if ast.get_docstring(node) is None:
                    violations.append(f"{path}:{node.lineno}:{node.name}:docstring")
                arguments = (
                    list(node.args.posonlyargs)
                    + list(node.args.args)
                    + list(node.args.kwonlyargs)
                )
                for argument in arguments:
                    if argument.arg in {"self", "cls"}:
                        continue
                    if argument.annotation is None:
                        violations.append(
                            f"{path}:{node.lineno}:{node.name}:{argument.arg}:type-hint"
                        )
                if node.returns is None:
                    violations.append(f"{path}:{node.lineno}:{node.name}:return-type")
        assert not violations, "Public production interfaces missing documentation/types:\n" + "\n".join(
            violations
        )
    except Exception:
        raise
