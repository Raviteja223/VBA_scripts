from datetime import date
from pathlib import Path
from types import SimpleNamespace

import pytest

from remarketing.config import load_config
from remarketing.errors import ReconciliationError, VisualFidelityError
from remarketing.models import (
    FidelityBuildResult,
    ReconciliationSummary,
    ReportArtifact,
    VisualFidelityResult,
)


def _config():
    try:
        return load_config()
    except Exception:
        raise


def _patch_common(monkeypatch, module, tmp_path, calls, *, mismatches=0, visual="PASS"):
    try:
        monkeypatch.setattr(
            module,
            "validate_workbook_contract",
            lambda *args, **kwargs: SimpleNamespace(report_as_of_date=date(2026, 9, 16)),
        )

        def fake_generate(**kwargs):
            try:
                calls.append("calculate")
                output = Path(kwargs["output_dir"]) / "calculated.xlsx"
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(b"calculated")
                return ReportArtifact(output, 28, 7, (), "2026-09-16")
            except Exception:
                raise

        def fake_reconcile(**kwargs):
            try:
                calls.append("business")
                output = Path(kwargs["reconciliation_output"])
                output.write_bytes(b"reconciliation")
                return ReconciliationSummary(mismatches, mismatches, str(output))
            except Exception:
                raise

        def fake_build(source_path, output_path, **kwargs):
            try:
                calls.append("fidelity")
                output = Path(output_path)
                output.write_bytes(Path(source_path).read_bytes())
                return FidelityBuildResult(output, ("Pivot Pierre", "Remarketing"), 0)
            except Exception:
                raise

        def fake_validate(*args, **kwargs):
            try:
                calls.append("visual")
                return VisualFidelityResult(status=visual, checks=())
            except Exception:
                raise

        monkeypatch.setattr(module, "generate_report_artifact", fake_generate)
        monkeypatch.setattr(module, "reconcile_report", fake_reconcile)
        monkeypatch.setattr(module, "build_fidelity_workbook", fake_build, raising=False)
        monkeypatch.setattr(module, "validate_visual_fidelity", fake_validate, raising=False)
        monkeypatch.setattr(
            module,
            "append_visual_fidelity_sheet",
            lambda path, *args, **kwargs: Path(path),
            raising=False,
        )
    except Exception:
        raise


def test_pipeline_builds_fidelity_only_after_business_reconciliation_passes(tmp_path, monkeypatch):
    try:
        import remarketing.pipeline as module

        calls = []
        _patch_common(monkeypatch, module, tmp_path, calls)
        source = tmp_path / "client.xlsx"
        source.write_bytes(b"source")
        artifact, reconciliation, _, visual = module._execute_reporting(
            input_path=source,
            workspace=tmp_path / "work",
            config=_config(),
            processing_date=date(2026, 9, 17),
        )
        assert calls == ["calculate", "business", "fidelity", "visual"]
        assert artifact.path.name == "REMARKETING_REPOSSESSION_REPORT_20260917.xlsx"
        assert reconciliation.unexplained_mismatch_count == 0
        assert visual.status == "PASS"
    except Exception:
        raise


def test_pipeline_does_not_build_fidelity_when_business_reconciliation_fails(
    tmp_path,
    monkeypatch,
):
    try:
        import remarketing.pipeline as module

        calls = []
        _patch_common(monkeypatch, module, tmp_path, calls, mismatches=1)
        source = tmp_path / "client.xlsx"
        source.write_bytes(b"source")
        with pytest.raises(ReconciliationError):
            module._execute_reporting(
                input_path=source,
                workspace=tmp_path / "work",
                config=_config(),
                processing_date=date(2026, 9, 17),
            )
        assert "fidelity" not in calls
    except Exception:
        raise


def test_pipeline_refuses_success_when_visual_fidelity_fails(tmp_path, monkeypatch):
    try:
        import remarketing.pipeline as module

        calls = []
        _patch_common(monkeypatch, module, tmp_path, calls, visual="FAIL")
        source = tmp_path / "client.xlsx"
        source.write_bytes(b"source")
        with pytest.raises(VisualFidelityError):
            module._execute_reporting(
                input_path=source,
                workspace=tmp_path / "work",
                config=_config(),
                processing_date=date(2026, 9, 17),
            )
        assert calls[-1] == "visual"
    except Exception:
        raise
