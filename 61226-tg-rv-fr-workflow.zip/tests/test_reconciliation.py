from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook

from remarketing.models import ExcelError


def test_integer_counts_require_exact_match():
    from remarketing.reconcile import compare_values

    assert compare_values(4, 4, "0").status == "MATCH"
    result = compare_values(4, 5, "0")
    assert result.status == "MISMATCH"
    assert result.category == "VALUE_MISMATCH"
    assert result.numeric_difference == 1


def test_float_values_allow_internal_tolerance_and_display_precision():
    from remarketing.reconcile import compare_values

    close = compare_values(1.0, 1.0 + 5e-10, "0.000000")
    assert close.status == "MATCH"
    assert close.category == "NUMERIC_TOLERANCE"

    displayed = compare_values(12.341, 12.344, '€ #,##0.00')
    assert displayed.status == "MATCH"
    assert displayed.category == "NUMERIC_TOLERANCE"
    assert displayed.numeric_difference == 0.0030000000000001137


def test_excel_errors_match_only_same_error_code():
    from remarketing.reconcile import compare_values

    preserved = compare_values(ExcelError("#REF!"), ExcelError("#REF!"), "General", known_source_error=True)
    assert preserved.status == "KNOWN_SOURCE_ERROR"
    assert preserved.category == "SOURCE_FORMULA_BROKEN_PRESERVED"

    mismatch = compare_values(ExcelError("#REF!"), ExcelError("#VALUE!"), "General")
    assert mismatch.status == "MISMATCH"
    assert mismatch.category == "UNSUPPORTED_SOURCE_ERROR"


def test_missing_generated_and_extra_generated_items_are_reported():
    from remarketing.reconcile import compare_keyed_values

    rows = compare_keyed_values(
        {"kept": (1, "0"), "missing": (2, "0")},
        {"kept": 1, "extra": 3},
    )
    by_key = {row.key: row for row in rows}
    assert by_key["missing"].category == "MISSING_GENERATED_ITEM"
    assert by_key["missing"].status == "MISMATCH"
    assert by_key["extra"].category == "EXTRA_GENERATED_ITEM"
    assert by_key["extra"].status == "MISMATCH"


def test_known_broken_kpi_error_gets_known_source_error_category():
    from remarketing.reconcile import compare_values

    result = compare_values(
        ExcelError("#REF!"), ExcelError("#REF!"), "General", known_source_error=True
    )
    assert result.status == "KNOWN_SOURCE_ERROR"
    assert result.explanation.startswith("Preserved analyst source error")


def test_reconciliation_workbook_has_exact_schema_summary_and_no_formulas(tmp_path):
    from remarketing.reconcile import ReconciliationRow, write_reconciliation_workbook

    rows = [
        ReconciliationRow(
            report_sheet="Pivot Pierre",
            section_id="pivot_pierre_01",
            logical_row_key="row:1",
            logical_column_key="col:1",
            data_field="",
            analyst_cell="A5",
            generated_cell="A5",
            analyst_value="X",
            generated_value="X",
            status="MATCH",
            numeric_difference=None,
            category="EXACT",
            explanation="Values match exactly",
        ),
        ReconciliationRow(
            report_sheet="KPIs",
            section_id="KPIs",
            logical_row_key="C4",
            logical_column_key="",
            data_field="",
            analyst_cell="C4",
            generated_cell="C4",
            analyst_value="#REF!",
            generated_value="#REF!",
            status="KNOWN_SOURCE_ERROR",
            numeric_difference=None,
            category="SOURCE_FORMULA_BROKEN_PRESERVED",
            explanation="Preserved analyst source error #REF!",
        ),
    ]
    path = write_reconciliation_workbook(rows, tmp_path / "reconciliation.xlsx")
    wb = load_workbook(path, data_only=False, keep_links=False)
    try:
        ws = wb["Reconciliation"]
        assert [cell.value for cell in ws[1]] == [
            "Report Sheet", "Section ID", "Logical Row Key", "Logical Column Key", "Data Field",
            "Analyst Cell", "Generated Cell", "Analyst Value", "Generated Value", "Status",
            "Numeric Difference", "Category", "Explanation",
        ]
        assert ws.freeze_panes == "A2"
        assert ws.auto_filter.ref == f"A1:M{ws.max_row}"
        assert "Summary" in wb.sheetnames
        assert not any(cell.data_type == "f" for sheet in wb.worksheets for row in sheet.iter_rows() for cell in row)
    finally:
        wb.close()
