from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
WATCHER = ROOT / "astro" / "dags" / "remarketing_file_watcher_dag.py"
PROCESSING = ROOT / "astro" / "dags" / "remarketing_processing_dag.py"


def _source(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        raise


def test_dags_bootstrap_sibling_include_directory_before_importing_package():
    try:
        for path in (WATCHER, PROCESSING):
            source = _source(path)
            assert "INCLUDE_ROOT" in source
            assert "sys.path.insert(0, str(INCLUDE_ROOT))" in source
            assert source.index("sys.path.insert(0, str(INCLUDE_ROOT))") < source.index(
                "from remarketing"
            )
    except Exception:
        raise


def test_watcher_dag_contract_is_present_in_source():
    try:
        source = _source(WATCHER)
        assert 'dag_id="remarketing_file_watcher_dag"' in source
        assert "schedule=DAG_CONFIG.watcher_schedule" in source
        assert "catchup=False" in source
        assert "max_active_runs=1" in source
        for task_id in (
            "list_input_objects",
            "validate_candidate_count",
            "trigger_processing_dag",
        ):
            assert f'task_id="{task_id}"' in source
    except Exception:
        raise


def test_processing_dag_contract_is_present_in_source():
    try:
        source = _source(PROCESSING)
        assert 'dag_id="remarketing_processing_dag"' in source
        assert "schedule=None" in source
        assert "catchup=False" in source
        assert "max_active_runs=1" in source
        for task_id in (
            "resolve_processing_request",
            "process_remarketing_workbook",
            "log_processing_result",
        ):
            assert f'task_id="{task_id}"' in source
    except Exception:
        raise
