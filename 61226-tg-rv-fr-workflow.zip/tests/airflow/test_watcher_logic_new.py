import pytest
from remarketing.errors import InputDiscoveryError
from dags.remarketing_file_watcher_dag import validate_candidate_count


def test_zero_candidates_is_false(): assert validate_candidate_count([]) is False

def test_one_candidate_is_returned():
    c={'bucket_name':'b','object_name':'input/a.xlsx','generation':1,'detection_timestamp':'x'}
    assert validate_candidate_count([c]) == c

def test_multiple_candidates_fail():
    with pytest.raises(InputDiscoveryError): validate_candidate_count([{'object_name':'a'},{'object_name':'b'}])
