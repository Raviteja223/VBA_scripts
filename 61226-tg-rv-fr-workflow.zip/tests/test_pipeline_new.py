from datetime import date
from pathlib import Path
import pytest
from remarketing.models import RunManifest, RunStatus
from remarketing.errors import AlreadyProcessedError
from remarketing.pipeline import _duplicate_manifest, _same_day_manifest


def manifest(day='2026-09-16', digest='samehash'):
    return RunManifest(status=RunStatus.SUCCESS, processing_date=day, source_file='a.xlsx', source_sha256=digest, archived_input='x', report='r', reconciliation='q', unexplained_mismatch_count=0)


def test_duplicate_hash_detected_even_when_filename_changes():
    assert _duplicate_manifest([manifest()], 'samehash') is not None


def test_same_day_success_detected():
    assert _same_day_manifest([manifest(day='2026-09-17', digest='other')], date(2026,9,17)) is not None
