"""Safe read-only helpers for OOXML package parts and relationships."""
from __future__ import annotations

import hashlib
import posixpath
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
from defusedxml import ElementTree as DefusedET

from .errors import OoxmlRelationshipError

REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


@dataclass(frozen=True, slots=True)
class OOXMLRelationship:
    """One OPC relationship from an OOXML package part."""

    rel_id: str
    rel_type: str
    target: str
    target_mode: str | None = None


def sha256_bytes(value: bytes) -> str:
    """Return a stable SHA-256 digest for raw OOXML bytes."""
    try:
        return hashlib.sha256(value).hexdigest()
    except Exception as exc:
        raise OoxmlRelationshipError("Unable to hash OOXML bytes") from exc


def relationship_part_name(source_part: str) -> str:
    """Return the OPC relationship-part path for a source part."""
    try:
        normalized = source_part.lstrip("/")
        if not normalized:
            return "_rels/.rels"
        directory = posixpath.dirname(normalized)
        basename = posixpath.basename(normalized)
        if directory:
            return posixpath.join(directory, "_rels", f"{basename}.rels")
        return posixpath.join("_rels", f"{basename}.rels")
    except Exception as exc:
        raise OoxmlRelationshipError(
            f"Unable to derive relationship part for: {source_part}"
        ) from exc


class OOXMLPackage:
    """Read-only helper for OPC parts and relationships."""

    def __init__(self, path: Path | str) -> None:
        try:
            self.path = Path(path)
            self._archive: ZipFile | None = None
        except Exception as exc:
            raise OoxmlRelationshipError(
                f"Unable to initialize OOXML package: {path}"
            ) from exc

    def __enter__(self) -> "OOXMLPackage":
        try:
            self._archive = ZipFile(self.path, "r")
            return self
        except Exception as exc:
            raise OoxmlRelationshipError(
                f"Unable to open OOXML package: {self.path}"
            ) from exc

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        try:
            if self._archive is not None:
                self._archive.close()
        except Exception as close_exc:
            raise OoxmlRelationshipError(
                f"Unable to close OOXML package: {self.path}"
            ) from close_exc

    def read_part(self, part_name: str) -> bytes:
        """Read one package part without transforming it."""
        try:
            if self._archive is None:
                raise OoxmlRelationshipError("OOXML package is not open")
            return self._archive.read(part_name.lstrip("/"))
        except OoxmlRelationshipError:
            raise
        except Exception as exc:
            raise OoxmlRelationshipError(
                f"Unable to read OOXML part: {part_name}"
            ) from exc

    def part_exists(self, part_name: str) -> bool:
        """Return whether a package member exists."""
        try:
            if self._archive is None:
                raise OoxmlRelationshipError("OOXML package is not open")
            return part_name.lstrip("/") in self._archive.namelist()
        except OoxmlRelationshipError:
            raise
        except Exception as exc:
            raise OoxmlRelationshipError(
                f"Unable to inspect OOXML part: {part_name}"
            ) from exc

    def part_names(self) -> tuple[str, ...]:
        """Return every package member name in archive order."""
        try:
            if self._archive is None:
                raise OoxmlRelationshipError("OOXML package is not open")
            return tuple(self._archive.namelist())
        except OoxmlRelationshipError:
            raise
        except Exception as exc:
            raise OoxmlRelationshipError("Unable to list OOXML parts") from exc

    def relationships(self, source_part: str) -> tuple[OOXMLRelationship, ...]:
        """Read relationships for one source part without following targets."""
        try:
            rels_name = relationship_part_name(source_part)
            if not self.part_exists(rels_name):
                return ()
            root = DefusedET.fromstring(self.read_part(rels_name))
            relationships: list[OOXMLRelationship] = []
            for node in root.findall(f"{{{REL_NS}}}Relationship"):
                relationships.append(
                    OOXMLRelationship(
                        rel_id=node.attrib.get("Id", ""),
                        rel_type=node.attrib.get("Type", ""),
                        target=node.attrib.get("Target", ""),
                        target_mode=node.attrib.get("TargetMode"),
                    )
                )
            return tuple(relationships)
        except OoxmlRelationshipError:
            raise
        except Exception as exc:
            raise OoxmlRelationshipError(
                f"Unable to parse relationships for: {source_part}"
            ) from exc

    def resolve_target(
        self,
        source_part: str,
        relationship: OOXMLRelationship,
    ) -> str | None:
        """Resolve an internal target to a normalized package path."""
        try:
            if relationship.target_mode == "External":
                return None
            target = relationship.target.replace("\\", "/")
            if target.startswith("/"):
                return posixpath.normpath(target).lstrip("/")
            base = posixpath.dirname(source_part.lstrip("/"))
            return posixpath.normpath(posixpath.join(base, target)).lstrip("/")
        except Exception as exc:
            raise OoxmlRelationshipError(
                f"Unable to resolve relationship {relationship.rel_id} from {source_part}"
            ) from exc
