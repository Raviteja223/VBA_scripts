"""Local and generation-safe Google Cloud Storage adapters."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from shutil import copy2
from typing import Any

from .errors import ConfigurationError, InputDiscoveryError, RemarketingError, StorageError
from .models import GCSObjectIdentity, RunManifest

try:
    from google.cloud import storage as google_storage
except ImportError:  # pragma: no cover - optional outside production.
    google_storage = None


@dataclass(frozen=True, slots=True)
class GCSObjectInfo:
    """Stable metadata for an exact GCS object generation."""

    name: str
    generation: int
    size: int = 0


class GCSStorage:
    """GCS adapter that uses generation preconditions for every mutation."""

    def __init__(self, bucket_name: str, client: Any | None = None):
        try:
            if not str(bucket_name).strip():
                raise ConfigurationError("GCS bucket name is required")
            resolved_client = client
            if resolved_client is None:
                if google_storage is None:
                    raise ConfigurationError(
                        "google-cloud-storage is required for production GCS processing"
                    )
                resolved_client = google_storage.Client()
            self._client = resolved_client
            self._bucket = self._client.bucket(bucket_name)
            self.bucket_name = str(bucket_name)
        except RemarketingError:
            raise
        except Exception as exc:
            raise ConfigurationError(f"Unable to configure GCS bucket {bucket_name!r}") from exc

    @staticmethod
    def _object_info(blob: Any) -> GCSObjectInfo:
        try:
            return GCSObjectInfo(
                name=str(blob.name),
                generation=int(blob.generation),
                size=int(blob.size or 0),
            )
        except Exception as exc:
            name = getattr(blob, "name", "<unknown>")
            raise StorageError(f"Unable to read GCS metadata for {name}") from exc

    def _list_objects(self, prefix: str) -> list[GCSObjectInfo]:
        try:
            blobs = self._client.list_blobs(self._bucket, prefix=prefix)
            return sorted(
                (
                    self._object_info(blob)
                    for blob in blobs
                    if not str(blob.name).endswith("/")
                ),
                key=lambda item: item.name,
            )
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(f"Unable to list GCS objects under {prefix!r}") from exc

    def list_xlsx_candidates(self, prefix: str = "input/") -> list[GCSObjectInfo]:
        """Return direct-child XLSX objects beneath the configured input prefix."""
        try:
            normalized = prefix if prefix.endswith("/") else f"{prefix}/"
            candidates: list[GCSObjectInfo] = []
            for item in self._list_objects(normalized):
                relative = (
                    item.name[len(normalized) :]
                    if item.name.startswith(normalized)
                    else item.name
                )
                if "/" not in relative and relative.lower().endswith(".xlsx"):
                    candidates.append(item)
            return candidates
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(
                f"Unable to discover XLSX candidates under {prefix!r}"
            ) from exc

    def list_input_candidates(self, prefix: str = "input/") -> list[GCSObjectIdentity]:
        """Return watcher-safe object identities for direct-child XLSX inputs."""
        try:
            return [
                GCSObjectIdentity(
                    bucket_name=self.bucket_name,
                    object_name=item.name,
                    generation=item.generation,
                    size=item.size,
                )
                for item in self.list_xlsx_candidates(prefix)
            ]
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError("Unable to list remarketing input candidates") from exc

    def list_xlsx_objects(self, prefix: str) -> list[GCSObjectInfo]:
        """Return all XLSX objects recursively beneath a prefix."""
        try:
            normalized = prefix if prefix.endswith("/") else f"{prefix}/"
            return [
                item
                for item in self._list_objects(normalized)
                if item.name.lower().endswith(".xlsx")
            ]
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(f"Unable to list XLSX objects under {prefix!r}") from exc

    def download_exact(self, object_info: GCSObjectInfo, destination: Path | str) -> Path:
        """Download exactly the observed GCS generation."""
        try:
            destination_path = Path(destination)
            destination_path.parent.mkdir(parents=True, exist_ok=True)
            blob = self._bucket.blob(object_info.name)
            blob.download_to_filename(
                str(destination_path),
                if_generation_match=object_info.generation,
            )
            return destination_path
        except Exception as exc:
            raise StorageError(
                f"Unable to download GCS object {object_info.name!r} at generation "
                f"{object_info.generation}"
            ) from exc

    def copy_exact(
        self,
        source: GCSObjectInfo,
        destination_name: str,
        destination_generation: int = 0,
    ) -> GCSObjectInfo:
        """Copy an exact source generation with a destination precondition."""
        try:
            source_blob = self._bucket.blob(source.name)
            copied = self._bucket.copy_blob(
                source_blob,
                self._bucket,
                new_name=destination_name,
                if_source_generation_match=source.generation,
                if_generation_match=destination_generation,
            )
            copied.reload()
            return self._object_info(copied)
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(
                f"Unable to copy GCS object {source.name!r} to {destination_name!r}"
            ) from exc

    def delete_exact(self, object_info: GCSObjectInfo) -> None:
        """Delete exactly the observed GCS generation."""
        try:
            blob = self._bucket.blob(object_info.name)
            blob.delete(if_generation_match=object_info.generation)
        except Exception as exc:
            raise StorageError(
                f"Unable to delete GCS object {object_info.name!r} at generation "
                f"{object_info.generation}"
            ) from exc

    def archive_exact(
        self,
        source: GCSObjectIdentity,
        destination_name: str,
    ) -> GCSObjectIdentity:
        """Copy, verify, then generation-delete one exact input object."""
        try:
            source_info = GCSObjectInfo(
                name=source.object_name,
                generation=source.generation,
                size=source.size,
            )
            existing = self.exists(destination_name)
            destination_generation = 0 if existing is None else existing.generation
            copied = self.copy_exact(
                source_info,
                destination_name,
                destination_generation=destination_generation,
            )
            verified = self.exists(destination_name)
            if verified is None or verified.generation != copied.generation:
                raise StorageError(f"Unable to verify archived object {destination_name!r}")
            self.delete_exact(source_info)
            return GCSObjectIdentity(
                bucket_name=self.bucket_name,
                object_name=copied.name,
                generation=copied.generation,
                size=copied.size,
            )
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(
                f"Unable to archive exact GCS object {source.object_name!r}"
            ) from exc

    def upload_file(
        self,
        source_path: Path | str,
        destination_name: str,
        *,
        if_generation_match: int,
    ) -> GCSObjectInfo:
        """Upload a file using an explicit destination generation precondition."""
        try:
            blob = self._bucket.blob(destination_name)
            blob.upload_from_filename(
                str(source_path),
                if_generation_match=if_generation_match,
            )
            blob.reload()
            return self._object_info(blob)
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(
                f"Unable to upload file to GCS object {destination_name!r}"
            ) from exc

    def upload_text(
        self,
        text: str,
        destination_name: str,
        *,
        if_generation_match: int,
    ) -> GCSObjectInfo:
        """Upload UTF-8 JSON/text with a destination generation precondition."""
        try:
            blob = self._bucket.blob(destination_name)
            blob.upload_from_string(
                text,
                content_type="application/json; charset=utf-8",
                if_generation_match=if_generation_match,
            )
            blob.reload()
            return self._object_info(blob)
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(
                f"Unable to upload text to GCS object {destination_name!r}"
            ) from exc

    def read_text(self, object_info: GCSObjectInfo) -> str:
        """Read exactly the observed object generation as text."""
        try:
            blob = self._bucket.blob(object_info.name)
            return blob.download_as_text(if_generation_match=object_info.generation)
        except Exception as exc:
            raise StorageError(
                f"Unable to read GCS object {object_info.name!r} at generation "
                f"{object_info.generation}"
            ) from exc

    def exists(self, object_name: str) -> GCSObjectInfo | None:
        """Return object metadata when an exact object name exists."""
        try:
            for item in self._list_objects(object_name):
                if item.name == object_name:
                    return item
            return None
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(f"Unable to inspect GCS object {object_name!r}") from exc

    def list_manifest_objects(self, output_prefix: str = "output/") -> list[GCSObjectInfo]:
        """Return dated SUCCESS-manifest object candidates."""
        try:
            normalized = (
                output_prefix if output_prefix.endswith("/") else f"{output_prefix}/"
            )
            pattern = re.compile(
                rf"^{re.escape(normalized)}\d{{4}}-\d{{2}}-\d{{2}}/output/"
                r"run_summary_\d{8}\.json$"
            )
            return [
                item
                for item in self._list_objects(normalized)
                if pattern.match(item.name)
            ]
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError(
                f"Unable to list production manifests under {output_prefix!r}"
            ) from exc

    def list_success_manifests(self, output_prefix: str = "output/") -> list[RunManifest]:
        """Parse all readable SUCCESS manifests beneath the output prefix."""
        try:
            manifests: list[RunManifest] = []
            for object_info in self.list_manifest_objects(output_prefix):
                manifest = RunManifest.from_json(self.read_text(object_info))
                if manifest.is_success:
                    manifests.append(manifest)
            return manifests
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError("Unable to list successful processing manifests") from exc


class LocalStorage:
    """Filesystem adapter that mirrors production dated output semantics."""

    def __init__(self, *, input_dir: Path | str, output_root: Path | str):
        try:
            self.input_dir = Path(input_dir)
            self.output_root = Path(output_root)
        except Exception as exc:
            raise StorageError("Unable to configure local storage") from exc

    def _safe_output_path(self, destination_relative: str) -> Path:
        try:
            relative = Path(destination_relative)
            if relative.is_absolute():
                raise StorageError("Destination path must be relative")
            if any(part == ".." for part in relative.parts):
                raise StorageError("Destination path cannot include parent traversal")
            output_root = self.output_root.resolve()
            destination = (output_root / relative).resolve()
            try:
                destination.relative_to(output_root)
            except ValueError:
                raise StorageError("Destination path escapes output root")
            return destination
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError("Unable to validate destination path") from exc

    def _safe_input_path(self, source: Path | str) -> Path:
        try:
            input_root = self.input_dir.resolve()
            candidate = Path(source).resolve(strict=True)
            if candidate.parent != input_root or not candidate.is_file():
                raise StorageError("Input must be a direct-child file of the input directory")
            if candidate.suffix.lower() != ".xlsx":
                raise StorageError("Input file must have an XLSX extension")
            return candidate
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError("Unable to validate input file path") from exc

    def resolve_single_input(self) -> Path | None:
        """Return zero or one direct-child XLSX, rejecting multiple candidates."""
        try:
            self.input_dir.mkdir(parents=True, exist_ok=True)
            candidates = sorted(
                path
                for path in self.input_dir.iterdir()
                if path.is_file() and path.suffix.lower() == ".xlsx"
            )
            if not candidates:
                return None
            if len(candidates) > 1:
                raise InputDiscoveryError(
                    f"Expected at most one XLSX, found {len(candidates)}"
                )
            return candidates[0]
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError("Unable to discover local input") from exc

    def archive_input(self, source: Path, paths: Any) -> Path:
        """Archive and remove the staged local input."""
        try:
            source = self._safe_input_path(source)
            destination = self._safe_output_path(str(paths.archived_input))
            destination.parent.mkdir(parents=True, exist_ok=True)
            copy2(source, destination)
            if source.resolve() != destination.resolve():
                source.unlink()
            return destination
        except Exception as exc:
            raise StorageError(f"Unable to archive local input {source}") from exc

    def publish_file(self, source: Path, destination_relative: str) -> Path:
        """Copy a generated file into the local production-equivalent layout."""
        try:
            destination = self._safe_output_path(destination_relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            copy2(source, destination)
            return destination
        except Exception as exc:
            raise StorageError(
                f"Unable to publish local file {destination_relative}"
            ) from exc

    def publish_text(self, text: str, destination_relative: str) -> Path:
        """Write text into the local production-equivalent layout."""
        try:
            destination = self._safe_output_path(destination_relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(text, encoding="utf-8")
            return destination
        except Exception as exc:
            raise StorageError(
                f"Unable to publish local text {destination_relative}"
            ) from exc

    def list_success_manifests(self) -> list[RunManifest]:
        """Parse local SUCCESS manifests from prior dated runs."""
        try:
            manifests: list[RunManifest] = []
            if not self.output_root.exists():
                return manifests
            for path in self.output_root.glob("*/output/run_summary_*.json"):
                manifest = RunManifest.from_json(path.read_text(encoding="utf-8"))
                if manifest.is_success:
                    manifests.append(manifest)
            return manifests
        except RemarketingError:
            raise
        except Exception as exc:
            raise StorageError("Unable to read local success manifests") from exc
