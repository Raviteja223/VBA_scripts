from __future__ import annotations

from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd

from include.remarketing.config_loader import load_project_configs
from include.remarketing.excel_reader import read_sheet
from include.remarketing.pipeline import process_workbook


def find_input_file() -> Path:
    configured = os.getenv("LOCAL_INPUT_FILE")
    if configured:
        path = Path(configured)
        if not path.exists():
            raise FileNotFoundError(f"LOCAL_INPUT_FILE does not exist: {path}")
        return path
    files = [p for p in (ROOT / "local_test" / "input").glob("*.xlsx") if not p.name.startswith("~$")]
    if len(files) != 1:
        raise RuntimeError(
            "local_test/input must contain exactly one XLSX file, or set LOCAL_INPUT_FILE. "
            f"Found {len(files)}."
        )
    return files[0]


def infer_period(path: Path, configs: dict[str, dict]) -> str:
    source_sheet = configs["workbook_config"].get("source_sheet", "Remarketing")
    event_date = configs["business_rules"]["columns"]["event_date"]
    frame = read_sheet(path, source_sheet, usecols=lambda c: str(c).strip().casefold() == event_date.casefold())
    if event_date not in frame.columns:
        raise KeyError(f"Cannot infer period because {event_date!r} was not read.")
    dates = pd.to_datetime(frame[event_date], errors="coerce").dropna()
    if dates.empty:
        raise ValueError("Cannot infer reporting period because event-date column has no valid dates.")
    return str(dates.max().to_period("M"))


def main() -> None:
    print("=" * 80)
    print("LOCAL REMARKETING PIPELINE TEST")
    print("=" * 80)
    configs = load_project_configs(ROOT / "config")
    input_path = find_input_file()
    period = os.getenv("TEST_PERIOD") or infer_period(input_path, configs)
    output_path = Path(os.getenv("LOCAL_OUTPUT_FILE", ROOT / "local_test" / "output" / "remarketing_report_local_test.xlsx"))

    print(f"Project root : {ROOT}")
    print(f"Input file   : {input_path}")
    print(f"Input size   : {input_path.stat().st_size / (1024 * 1024):.2f} MB")
    print(f"Period       : {period}")
    print(f"Output file  : {output_path}")

    result = process_workbook(input_path, output_path, configs, period)
    print("\nProcessing complete.")
    print(f"Source rows  : {result.source_count}")
    print(f"Valid rows   : {result.valid_count}")
    print(f"Excluded rows: {result.excluded_count}")
    print(f"Sheets       : {', '.join(result.sheet_names)}")
    print("Reconciliation:")
    for key, value in result.reconciliation.items():
        print(f"  {key}: {value}")
    print(f"\nGenerated report: {result.output_path}")


if __name__ == "__main__":
    main()
