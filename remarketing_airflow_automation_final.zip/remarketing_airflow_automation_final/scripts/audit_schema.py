from __future__ import annotations

from difflib import get_close_matches
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from include.remarketing.config_loader import load_project_configs
from include.remarketing.data_validation import build_column_lookup, normalize_column_key
from include.remarketing.excel_reader import read_sheet, sheet_names

SOURCE_RULE_KEYS = ("status_raw", "event_date", "settlement_date", "return_date")


def find_input_file() -> Path:
    files = [p for p in (ROOT / "local_test" / "input").glob("*.xlsx") if not p.name.startswith("~$")]
    if len(files) != 1:
        raise RuntimeError(f"Expected exactly one XLSX in local_test/input; found {len(files)}.")
    return files[0]


def main() -> None:
    path = find_input_file()
    configs = load_project_configs(ROOT / "config")
    workbook_cfg = configs["workbook_config"]
    business_cfg = configs["business_rules"]
    source_sheet = workbook_cfg.get("source_sheet", "Remarketing")

    print("=" * 90)
    print("REMARKETING PROJECT - COMPLETE SCHEMA AUDIT")
    print("=" * 90)
    print(f"Workbook: {path}")
    print(f"Workbook sheet count: {len(sheet_names(path))}")

    df = read_sheet(path, source_sheet, nrows=0)
    print(f"\n{source_sheet}: {len(df.columns)} columns")
    for i, column in enumerate(df.columns):
        print(f"{i:>3}: {column!r}")

    required: list[tuple[str, str]] = []
    for key in ("required_columns", "business_keys", "text_columns"):
        for index, value in enumerate(workbook_cfg.get(key, []) or []):
            required.append((f"workbook_config.{key}[{index}]", value))
    columns = business_cfg.get("columns", {})
    for logical in SOURCE_RULE_KEYS:
        if columns.get(logical):
            required.append((f"business_rules.columns.{logical}", columns[logical]))

    lookup = build_column_lookup(df)
    actual_by_key = {normalize_column_key(c): c for c in df.columns}
    missing = []

    print("\nCONFIGURATION COLUMN AUDIT")
    for path_name, configured in required:
        key = normalize_column_key(configured)
        actual = lookup.get(key)
        if actual is not None:
            print(f"OK       {path_name} -> {configured!r} -> {actual!r}")
            continue
        close = get_close_matches(key, list(actual_by_key), n=5, cutoff=0.45)
        suggestions = [actual_by_key[item] for item in close]
        missing.append((path_name, configured, suggestions))
        print(f"MISSING  {path_name} -> {configured!r}")
        for suggestion in suggestions:
            print(f"         suggestion only: {suggestion!r}")

    print("\nSUMMARY")
    print(f"Configured source references: {len(required)}")
    print(f"Missing references: {len(missing)}")
    if missing:
        raise SystemExit(1)
    print("SCHEMA AUDIT PASSED")


if __name__ == "__main__":
    main()
