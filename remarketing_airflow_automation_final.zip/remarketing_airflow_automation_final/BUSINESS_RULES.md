# Business Rules

## Confirmed from the real workbook schema

The local source sheet is `Remarketing`. Confirmed columns used by the current pipeline include:

- `Contrat`
- `VIN`
- `Statut`
- `Date de retour`
- `date vente`
- `Vendeur`
- `Model`

French business-facing labels are preserved.

## Current automated rules

The current code derives `Statut calculé` from `Statut` using `Solde` as the settled label and `Non Solde` for other non-null statuses.

The current inventory-age implementation uses `Date de retour` as the event/start date. For rows classified as `Solde`, age is `date vente - Date de retour`; for other non-null statuses, age is `reporting period end - Date de retour`. Missing statuses remain unclassified and produce no age.

The current aging thresholds are 30, 60, 90, 120, 150, 180, and 360 days. These values came from the generated project configuration and must be reconciled with the analyst walkthrough before production sign-off.

`Mois de retour` and `Année de Retour` are derived from `Date de retour`.

## Reporting behavior

`Rapport Remarketing` currently contains generic monthly metrics for the configured reporting period. `Rapport ERA` currently contains the year-to-date row slice. Exact manual PivotTable layouts and business aggregations must be added to `report_config.yaml` after they are confirmed from the analyst walkthrough or approved workbook metadata.
