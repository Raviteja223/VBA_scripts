# Remarketing Automation Design

## Goal
Automate the Excel-based remarketing/repossessions reporting workflow using Python and Airflow/Astronomer, with local execution against a copied production workbook and production execution from GCS.

## Architecture
The project separates orchestration from business logic. Airflow DAGs pass only small metadata, while workbook processing happens inside pure Python modules. Local testing uses the same processing package as Airflow. No BigQuery or dbt is introduced.

## Confirmed workbook schema
- Primary source sheet: `Remarketing`
- Confirmed source columns include `Contrat`, `VIN`, `Statut`, `Date de retour`, `date vente`, `Vendeur`, and `Model`.
- Business-facing French labels are preserved.

## Business-rule boundary
The current generated rules use `Statut` to derive a calculated status, `Date de retour` as the event/return date, and `date vente` as the settlement/sale date for inventory-age calculations. These rules remain isolated in configuration and `calculations.py` because their exact business meaning must still be reconciled with the analyst walkthrough.

## Data flow
1. GCS upload triggers the watcher DAG externally.
2. Watcher validates metadata and triggers the processing DAG.
3. Processing DAG downloads the exact GCS object, archives a raw copy, and runs the Python processing pipeline.
4. Pipeline validates workbook structure and source columns, standardizes configured text fields, applies configured mappings, calculates derived fields, creates monthly/YTD outputs and configured pivot-equivalent tables, reconciles counts, and writes an XLSX report.
5. Processing DAG uploads the report and an audit JSON record to GCS.

## Local flow
The local runner reads a copy from `local_test/input`, performs schema audit and processing, and writes results under `local_test/output` without modifying the source workbook.

## Error handling
Critical schema or calculation failures raise explicit exceptions and prevent report publication. Nullable Excel/pandas values are handled explicitly. Missing business rules are not guessed; configurable outputs remain empty until confirmed.

## Testing
Unit tests cover header normalization, source-column validation, nullable-status calculations, monthly/YTD filtering, reconciliation, and an end-to-end synthetic workbook pipeline.
