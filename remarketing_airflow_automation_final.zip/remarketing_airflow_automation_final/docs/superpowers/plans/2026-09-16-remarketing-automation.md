# Remarketing Automation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a complete local-test and Airflow/Astronomer Python project for the remarketing workbook automation.

**Architecture:** Pure Python modules own workbook validation, standardization, calculations, reporting, and reconciliation. Airflow DAGs orchestrate GCS metadata and call the same pipeline used by the local runner. Large workbook data never travels through XCom.

**Tech Stack:** Python, pandas, openpyxl, XlsxWriter, PyYAML, google-cloud-storage, Apache Airflow/Astronomer.

**Spec:** `docs/superpowers/specs/2026-09-16-remarketing-automation-design.md`

## Global Constraints
- Preserve French business-facing column names.
- Do not require BigQuery or dbt.
- Do not modify the source workbook.
- Do not pass DataFrames or workbook bytes through Airflow XCom.
- Treat unverified business logic as configurable and document it.

---

### Task 1: Core workbook/config package
**Files:** config loader, Excel reader, validation, standardization, exceptions.
- [ ] Write tests for Unicode header normalization and source-column resolution.
- [ ] Run tests and verify failure before implementation.
- [ ] Implement readers and validators.
- [ ] Run tests and verify pass.

### Task 2: Business calculations
**Files:** `include/remarketing/calculations.py` and tests.
- [ ] Write nullable-status inventory-age regression tests.
- [ ] Verify the regression test fails without the fix.
- [ ] Implement calculation helpers and `apply_rules`.
- [ ] Verify tests pass.

### Task 3: Reporting and reconciliation
**Files:** monthly/YTD/pivot/report builder/reconciliation modules and tests.
- [ ] Write filtering and reconciliation tests.
- [ ] Implement deterministic reporting functions.
- [ ] Verify tests pass.

### Task 4: Processing pipeline and local tools
**Files:** pipeline, `scripts/run_local.py`, `scripts/audit_schema.py`, configs.
- [ ] Write synthetic end-to-end pipeline test.
- [ ] Implement pipeline and local scripts.
- [ ] Verify synthetic pipeline writes XLSX successfully.

### Task 5: Airflow/GCS orchestration
**Files:** watcher DAG, processing DAG, GCS utilities, audit/notifications.
- [ ] Implement metadata-only watcher DAG.
- [ ] Implement single-worker workbook-processing task using GCS download/upload.
- [ ] Ensure no DataFrames are placed into XCom.
- [ ] Compile DAG Python files.

### Task 6: Documentation and packaging
**Files:** README, BUSINESS_RULES, OPEN_QUESTIONS, requirements, pytest config.
- [ ] Document local execution and GCS/Airflow integration.
- [ ] Run full pytest suite.
- [ ] Run Python compile check over the project.
- [ ] Package the verified project as a ZIP.
