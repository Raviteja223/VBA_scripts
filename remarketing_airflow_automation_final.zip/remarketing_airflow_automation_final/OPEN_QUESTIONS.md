# Open Questions

1. Confirm that `Solde` is the correct value for the settled/sold state and that every other non-null `Statut` should become `Non Solde`.
2. Confirm that inventory age starts from `Date de retour` and, for settled vehicles, ends at `date vente`.
3. Confirm the aging thresholds and the exact French labels expected in the final report.
4. Confirm whether `Contrat` is the correct business key and whether duplicates are valid. Uniqueness enforcement is currently disabled.
5. Confirm the exact monthly report metrics, filters, grouping fields, and PivotTable aggregations.
6. Confirm the exact ERA report definition. The current implementation outputs the current-year rows through the reporting month as a technical YTD slice.
7. Confirm historical-correction behavior: which periods must be rebuilt when an earlier month changes.
8. Confirm whether final users require native interactive Excel PivotTable objects or only equivalent summarized tables in XLSX.
9. Confirm required seller/channel lookup sheets and mapping rules. `column_mapping.yaml` currently has no configured reference lookups.
10. Confirm which monetary fields, if any, should use VAT, collection-fee, residual, or mileage-charge helpers. Those helper APIs are preserved but are not applied automatically.
