from __future__ import annotations

from datetime import datetime, timedelta

from airflow.decorators import dag, task
from airflow.operators.trigger_dagrun import TriggerDagRunOperator


@dag(
    dag_id="remarketing_file_watcher",
    description="Receives GCS object metadata and triggers remarketing processing.",
    schedule=None,
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=4,
    render_template_as_native_obj=True,
    default_args={
        "owner": "data-engineering",
        "retries": 2,
        "retry_delay": timedelta(minutes=2),
    },
    tags=["remarketing", "gcs", "event-driven"],
)
def remarketing_file_watcher():
    @task
    def validate_input_metadata(**context) -> dict:
        conf = dict((context.get("dag_run") and context["dag_run"].conf) or {})
        bucket = str(conf.get("bucket", "")).strip()
        object_name = str(conf.get("object_name", "")).strip()
        generation = conf.get("generation")
        period = conf.get("period")

        if not bucket:
            raise ValueError("dag_run.conf.bucket is required.")
        if not object_name:
            raise ValueError("dag_run.conf.object_name is required.")
        if not object_name.lower().endswith((".xlsx", ".xlsm")):
            raise ValueError(f"Unsupported uploaded file: {object_name}")

        return {
            "bucket": bucket,
            "object_name": object_name,
            "generation": generation,
            "period": period,
        }

    metadata = validate_input_metadata()

    trigger_processing = TriggerDagRunOperator(
        task_id="trigger_processing",
        trigger_dag_id="remarketing_processing",
        conf="{{ ti.xcom_pull(task_ids='validate_input_metadata') }}",
        wait_for_completion=False,
        reset_dag_run=False,
    )

    metadata >> trigger_processing


remarketing_file_watcher()
