from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import json
import tempfile

from airflow.decorators import dag, task

from include.remarketing.audit import write_audit_json
from include.remarketing.config_loader import load_project_configs
from include.remarketing.gcs_utils import copy_gcs_object, download_gcs_file, upload_gcs_file
from include.remarketing.notifications import notify_success
from include.remarketing.pipeline import process_workbook


@dag(
    dag_id="remarketing_processing",
    description="Processes one remarketing Excel object from GCS and publishes the report.",
    schedule=None,
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=2,
    render_template_as_native_obj=True,
    default_args={
        "owner": "data-engineering",
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
    },
    tags=["remarketing", "excel", "gcs"],
)
def remarketing_processing():
    @task(execution_timeout=timedelta(hours=2))
    def process_gcs_workbook(**context) -> dict:
        conf = dict((context.get("dag_run") and context["dag_run"].conf) or {})
        bucket = str(conf.get("bucket", "")).strip()
        object_name = str(conf.get("object_name", "")).strip()
        period = conf.get("period")
        if not bucket or not object_name:
            raise ValueError("Processing DAG requires bucket and object_name in dag_run.conf.")

        source_uri = f"gs://{bucket}/{object_name}"
        run_id = str(context.get("run_id", "manual")).replace(":", "_").replace("/", "_")
        project_root = Path(__file__).resolve().parents[1]
        configs = load_project_configs(project_root / "config")

        with tempfile.TemporaryDirectory(prefix="remarketing_") as temp_dir_name:
            temp_dir = Path(temp_dir_name)
            local_input = temp_dir / Path(object_name).name
            local_output = temp_dir / f"{Path(object_name).stem}_report.xlsx"
            download_gcs_file(source_uri, local_input)

            if not period:
                from scripts.run_local import infer_period
                period = infer_period(local_input, configs)

            year, month = str(period).split("-", 1)
            raw_uri = f"gs://{bucket}/raw/{year}/{month}/{run_id}/{Path(object_name).name}"
            report_uri = f"gs://{bucket}/reports/{year}/{month}/{Path(object_name).stem}_report.xlsx"
            audit_uri = f"gs://{bucket}/audit/{year}/{month}/{run_id}.json"

            copy_gcs_object(source_uri, raw_uri)
            result = process_workbook(local_input, local_output, configs, str(period))
            upload_gcs_file(local_output, report_uri)

            audit_local = temp_dir / "audit.json"
            write_audit_json(
                audit_local,
                {
                    "source_uri": source_uri,
                    "raw_uri": raw_uri,
                    "report_uri": report_uri,
                    "period": period,
                    "source_count": result.source_count,
                    "valid_count": result.valid_count,
                    "excluded_count": result.excluded_count,
                    "reconciliation": result.reconciliation,
                },
            )
            upload_gcs_file(audit_local, audit_uri)

        return {
            "source_uri": source_uri,
            "raw_uri": raw_uri,
            "report_uri": report_uri,
            "audit_uri": audit_uri,
            "period": period,
            "reconciliation": result.reconciliation,
        }

    @task
    def notify(metadata: dict) -> None:
        notify_success("Remarketing report generated", metadata)

    metadata = process_gcs_workbook()
    notify(metadata)


remarketing_processing()
