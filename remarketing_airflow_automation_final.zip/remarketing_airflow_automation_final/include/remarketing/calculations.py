from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd

from .constants import DEFAULT_AGING_BUCKETS


def as_of_date(period: str) -> pd.Timestamp:
    try:
        return pd.Period(period, freq="M").end_time.normalize()
    except Exception as exc:
        raise ValueError(f"Invalid reporting period {period!r}; expected YYYY-MM.") from exc


def add_date_parts(
    df: pd.DataFrame,
    date_col: str,
    month_col: str,
    year_col: str,
) -> pd.DataFrame:
    if date_col not in df.columns:
        raise KeyError(f"Date column {date_col!r} does not exist.")
    dates = pd.to_datetime(df[date_col], errors="coerce")
    df[month_col] = dates.dt.month.astype("Int64")
    df[year_col] = dates.dt.year.astype("Int64")
    return df


def inventory_status(
    raw: pd.Series,
    settled_label: str = "Solde",
    unsettled_label: str = "Non Solde",
) -> pd.Series:
    status = raw.astype("string")
    normalized = status.str.strip().str.casefold()
    settled_key = str(settled_label).strip().casefold()
    result = pd.Series(pd.NA, index=raw.index, dtype="string")
    valid = status.notna()
    is_settled = normalized.eq(settled_key).fillna(False)
    result.loc[valid & is_settled] = settled_label
    result.loc[valid & ~is_settled] = unsettled_label
    return result


def inventory_age_days(
    status: pd.Series,
    event_date: pd.Series,
    settlement_date: pd.Series,
    as_of: pd.Timestamp | str,
) -> pd.Series:
    status_series = status.astype("string")
    event = pd.to_datetime(event_date, errors="coerce")
    settlement = pd.to_datetime(settlement_date, errors="coerce")
    reporting_date = pd.Timestamp(as_of)

    is_settled = (
        status_series.str.strip().str.casefold().eq("solde").fillna(False).to_numpy(dtype=bool)
    )
    is_missing_status = status_series.isna().to_numpy(dtype=bool)

    settled_age = (settlement - event).dt.days.astype("Float64")
    unsettled_age = (reporting_date - event).dt.days.astype("Float64")
    result = unsettled_age.copy()
    result.loc[is_settled] = settled_age.loc[is_settled]
    result.loc[is_missing_status] = pd.NA
    result.loc[event.isna()] = pd.NA
    return result.astype("Float64")


def age_bucket(
    days: pd.Series,
    buckets: list[int] | None = None,
    labels: list[str] | None = None,
) -> pd.Series:
    clean = sorted({int(value) for value in (buckets or DEFAULT_AGING_BUCKETS)})
    if not clean:
        raise ValueError("At least one aging threshold is required.")
    numeric = pd.to_numeric(days, errors="coerce")
    edges: list[float] = [-np.inf, *clean, np.inf]
    if labels is None:
        labels = [f"<= {clean[0]}"]
        labels.extend(f"{previous + 1}-{current}" for previous, current in zip(clean, clean[1:]))
        labels.append(f"> {clean[-1]}")
    if len(labels) != len(edges) - 1:
        raise ValueError("aging_bucket_labels must contain one label per resulting bucket.")
    bucketed = pd.cut(numeric, bins=edges, labels=labels, include_lowest=True, right=True)
    result = pd.Series(bucketed, index=days.index).astype("string")
    result.loc[numeric.isna()] = pd.NA
    return result


def maturity_months(date: pd.Series, as_of: pd.Timestamp | str) -> pd.Series:
    dates = pd.to_datetime(date, errors="coerce")
    end = pd.Timestamp(as_of)
    result = ((end.year - dates.dt.year) * 12 + (end.month - dates.dt.month)).astype("Float64")
    result.loc[dates.isna()] = pd.NA
    return result


def net_of_vat(gross: pd.Series, rate: float = 0.2) -> pd.Series:
    if rate <= -1:
        raise ValueError("VAT rate must be greater than -1.")
    values = pd.to_numeric(gross, errors="coerce")
    return (values / (1.0 + float(rate))).astype("Float64")


def capped_collection_fee(base: pd.Series, rate: float = 0.08, cap: float = 1200) -> pd.Series:
    values = pd.to_numeric(base, errors="coerce")
    return (values * float(rate)).clip(upper=float(cap)).astype("Float64")


def monthly_amount(annual: pd.Series) -> pd.Series:
    return (pd.to_numeric(annual, errors="coerce") / 12.0).astype("Float64")


def residual_floor(principal: pd.Series, monthly: pd.Series, months: pd.Series) -> pd.Series:
    principal_values = pd.to_numeric(principal, errors="coerce")
    monthly_values = pd.to_numeric(monthly, errors="coerce")
    month_values = pd.to_numeric(months, errors="coerce")
    return (principal_values - monthly_values * month_values).clip(lower=0).astype("Float64")


def mileage_charge(residual: pd.Series, vehicle_value: pd.Series, rate: float = 0.005) -> pd.Series:
    residual_values = pd.to_numeric(residual, errors="coerce")
    vehicle_values = pd.to_numeric(vehicle_value, errors="coerce")
    return ((vehicle_values - residual_values).clip(lower=0) * float(rate)).astype("Float64")


def apply_rules(df: pd.DataFrame, cfg: dict, period: str) -> pd.DataFrame:
    columns = cfg.get("columns", {})
    if not isinstance(columns, dict):
        raise TypeError("business_rules.columns must be a mapping.")
    output = df.copy()
    reporting_date = as_of_date(period)

    status_raw = columns.get("status_raw")
    status = columns.get("status")
    if status_raw and status and status_raw in output.columns:
        output[status] = inventory_status(
            output[status_raw],
            settled_label=cfg.get("settled_label", "Solde"),
            unsettled_label=cfg.get("unsettled_label", "Non Solde"),
        )

    event_date = columns.get("event_date")
    settlement_date = columns.get("settlement_date")
    age_days = columns.get("age_days")
    age_bucket_col = columns.get("age_bucket")
    if (
        age_days
        and status in output.columns
        and event_date in output.columns
        and settlement_date in output.columns
    ):
        output[age_days] = inventory_age_days(
            output[status], output[event_date], output[settlement_date], reporting_date
        )
        if age_bucket_col:
            output[age_bucket_col] = age_bucket(
                output[age_days],
                cfg.get("aging_buckets"),
                cfg.get("aging_bucket_labels"),
            )

    return_date = columns.get("return_date")
    return_month = columns.get("return_month")
    return_year = columns.get("return_year")
    if return_date and return_month and return_year and return_date in output.columns:
        add_date_parts(output, return_date, return_month, return_year)

    return output
