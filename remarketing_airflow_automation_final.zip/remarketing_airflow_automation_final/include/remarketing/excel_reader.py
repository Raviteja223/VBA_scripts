from __future__ import annotations

from pathlib import Path
from typing import Any
import unicodedata

import pandas as pd
from openpyxl import load_workbook


def normalize_header(value: Any) -> str:
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value))
    text = (
        text.replace("\xa0", " ")
        .replace("\u2007", " ")
        .replace("\u202f", " ")
        .replace("\u200b", "")
        .replace("\u200c", "")
        .replace("\u200d", "")
        .replace("\ufeff", "")
    )
    return " ".join(text.split()).strip()


def _normalize_dataframe_columns(df: pd.DataFrame) -> pd.DataFrame:
    original = list(df.columns)
    normalized = [normalize_header(column) for column in original]
    duplicates = sorted({name for name in normalized if normalized.count(name) > 1})
    if duplicates:
        details = []
        for duplicate in duplicates:
            sources = [repr(src) for src, dst in zip(original, normalized) if dst == duplicate]
            details.append(f"{duplicate!r} <- {', '.join(sources)}")
        raise ValueError(
            "Duplicate Excel column names were created after header normalization:\n"
            + "\n".join(details)
        )
    result = df.copy()
    result.columns = normalized
    return result


def sheet_names(path: Path | str) -> list[str]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Excel workbook not found: {path}")
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        return list(workbook.sheetnames)
    finally:
        workbook.close()


def read_sheet(path: Path | str, sheet: str, **kwargs: Any) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Excel workbook not found: {path}")
    available = sheet_names(path)
    if sheet not in available:
        raise KeyError(f"Worksheet {sheet!r} not found. Available sheets: {available}")
    df = pd.read_excel(path, sheet_name=sheet, engine="openpyxl", **kwargs)
    return _normalize_dataframe_columns(df)


def read_configured(path: Path | str, sheets: list[str]) -> dict[str, pd.DataFrame]:
    if not sheets:
        raise ValueError("No worksheet names supplied to read_configured().")
    available = set(sheet_names(path))
    missing = [sheet for sheet in sheets if sheet not in available]
    if missing:
        raise KeyError("Configured worksheet(s) do not exist: " + ", ".join(missing))
    return {sheet: read_sheet(path, sheet) for sheet in sheets}
