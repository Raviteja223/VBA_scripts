from __future__ import annotations

from typing import Any

import pandas as pd


def _count(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, pd.DataFrame):
        return int(len(value))
    return int(value)


def reconcile(
    source,
    valid,
    excluded,
    monthly: pd.DataFrame | None = None,
    ytd: pd.DataFrame | None = None,
) -> dict:
    source_count = _count(source)
    valid_count = _count(valid)
    excluded_count = _count(excluded)
    result = {
        "source_count": source_count,
        "valid_count": valid_count,
        "excluded_count": excluded_count,
        "source_equals_valid_plus_excluded": source_count == valid_count + excluded_count,
    }
    if monthly is not None and not monthly.empty and "record_count" in monthly.columns:
        result["monthly_record_count"] = int(monthly.iloc[0]["record_count"])
    if ytd is not None:
        result["ytd_record_count"] = int(len(ytd))
    return result
