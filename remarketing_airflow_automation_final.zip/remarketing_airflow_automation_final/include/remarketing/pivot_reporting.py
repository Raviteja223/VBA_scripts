from __future__ import annotations

from typing import Any

import pandas as pd


def _apply_filters(df: pd.DataFrame, filters: dict[str, Any]) -> pd.DataFrame:
    result = df
    for column, expected in (filters or {}).items():
        if column not in result.columns:
            raise KeyError(f"Pivot filter column {column!r} does not exist.")
        if isinstance(expected, list):
            result = result[result[column].isin(expected)]
        else:
            result = result[result[column].eq(expected)]
    return result


def build_configured_pivots(df: pd.DataFrame, configs: list[dict]) -> dict[str, pd.DataFrame]:
    outputs: dict[str, pd.DataFrame] = {}
    for spec in configs or []:
        name = str(spec["name"])
        filtered = _apply_filters(df, spec.get("filters", {}))
        index = spec.get("index") or []
        columns = spec.get("columns") or []
        values = spec.get("values")
        aggfunc = spec.get("aggfunc", "count")
        pivot = pd.pivot_table(
            filtered,
            index=index or None,
            columns=columns or None,
            values=values,
            aggfunc=aggfunc,
            fill_value=0,
            dropna=False,
        )
        outputs[name] = pivot.reset_index()
    return outputs
