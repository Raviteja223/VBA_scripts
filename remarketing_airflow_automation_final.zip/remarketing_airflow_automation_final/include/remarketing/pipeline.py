from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from .calculations import apply_rules
from .data_validation import (
    resolve_actual_column,
    split_valid_invalid_rows,
    validate_business_keys,
    validate_required_columns,
)
from .excel_reader import read_sheet
from .mappings import left_lookup
from .monthly_reporting import monthly_metrics
from .pivot_reporting import build_configured_pivots
from .reconciliation import reconcile
from .report_builder import build_report
from .standardization import standardize
from .workbook_validation import validate_workbook
from .ytd_reporting import ytd_slice


BUSINESS_SOURCE_KEYS = ("status_raw", "event_date", "settlement_date", "return_date")
BUSINESS_DERIVED_KEYS = ("status", "age_days", "age_bucket", "return_month", "return_year")


@dataclass(frozen=True)
class ProcessingResult:
    output_path: Path
    period: str
    source_count: int
    valid_count: int
    excluded_count: int
    reconciliation: dict
    sheet_names: list[str]


def _required_source_columns(workbook_cfg: dict, business_cfg: dict) -> list[str]:
    required: list[str] = []
    for key in ("required_columns", "business_keys", "text_columns"):
        required.extend(workbook_cfg.get(key, []) or [])
    columns = business_cfg.get("columns", {})
    for logical in BUSINESS_SOURCE_KEYS:
        if columns.get(logical):
            required.append(columns[logical])
    return required


def _validate_derived_columns(df: pd.DataFrame, business_cfg: dict) -> None:
    columns = business_cfg.get("columns", {})
    expected = [columns[key] for key in BUSINESS_DERIVED_KEYS if columns.get(key)]
    validate_required_columns(df, expected)


def _apply_reference_lookups(
    df: pd.DataFrame,
    input_path: Path,
    lookup_specs: list[dict],
) -> pd.DataFrame:
    result = df
    for spec in lookup_specs or []:
        ref = read_sheet(input_path, spec["sheet"])
        result = left_lookup(
            result,
            ref,
            spec["left_key"],
            spec["right_key"],
            spec.get("value_columns", []),
            bool(spec.get("required", False)),
        )
    return result


def process_workbook(
    input_path: Path | str,
    output_path: Path | str,
    configs: dict[str, dict],
    period: str,
) -> ProcessingResult:
    input_path = Path(input_path)
    output_path = Path(output_path)
    workbook_cfg = configs["workbook_config"]
    business_cfg = configs["business_rules"]
    mapping_cfg = configs.get("column_mapping", {})
    report_cfg = configs.get("report_config", {})

    validate_workbook(
        input_path,
        workbook_cfg.get("required_sheets", []),
        int(workbook_cfg.get("max_bytes", 0) or 0),
    )

    source_sheet = workbook_cfg.get("source_sheet", "Remarketing")
    source = read_sheet(input_path, source_sheet)
    validate_required_columns(source, _required_source_columns(workbook_cfg, business_cfg))

    working = standardize(source, workbook_cfg.get("text_columns", []))
    validate_business_keys(
        working,
        workbook_cfg.get("business_keys", []),
        enforce_unique=bool(workbook_cfg.get("enforce_unique_business_keys", False)),
    )

    valid, excluded = split_valid_invalid_rows(
        working,
        workbook_cfg.get("mandatory_fields", []),
    )
    valid = _apply_reference_lookups(
        valid,
        input_path,
        mapping_cfg.get("reference_lookups", []),
    )
    calculated = apply_rules(valid, business_cfg, period)
    _validate_derived_columns(calculated, business_cfg)

    event_config = business_cfg["columns"]["event_date"]
    event_date = resolve_actual_column(calculated, event_config)
    value_columns = [resolve_actual_column(calculated, c) for c in report_cfg.get("value_columns", [])]
    monthly = monthly_metrics(calculated, event_date, value_columns, period)
    ytd = ytd_slice(calculated, event_date, period)
    pivots = build_configured_pivots(calculated, report_cfg.get("pivots", []))

    output_cfg = workbook_cfg.get("output", {})
    detail_name = output_cfg.get("detail_sheet", "Remarketing")
    remarketing_name = output_cfg.get("remarketing_sheet", "Rapport Remarketing")
    era_name = output_cfg.get("era_sheet", "Rapport ERA")
    sheets: dict[str, pd.DataFrame] = {
        detail_name: calculated,
        remarketing_name: monthly,
        era_name: ytd,
        **pivots,
    }
    build_report(output_path, sheets, mapping_cfg.get("french_labels", {}))
    reconciliation = reconcile(source, calculated, excluded, monthly=monthly, ytd=ytd)

    return ProcessingResult(
        output_path=output_path,
        period=period,
        source_count=len(source),
        valid_count=len(calculated),
        excluded_count=len(excluded),
        reconciliation=reconciliation,
        sheet_names=list(sheets.keys()),
    )
