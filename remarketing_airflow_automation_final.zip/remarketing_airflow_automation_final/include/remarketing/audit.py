from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
from typing import Any


def write_audit_json(path: Path | str, payload: dict[str, Any]) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    document = {"written_at_utc": datetime.now(timezone.utc).isoformat(), **payload}
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return path
