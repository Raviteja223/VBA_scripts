from __future__ import annotations

from pathlib import Path

import pandas as pd


def _safe_sheet_name(name: str) -> str:
    forbidden = set('[]:*?/\\')
    cleaned = "".join("_" if ch in forbidden else ch for ch in str(name))
    return cleaned[:31] or "Sheet"


def build_report(
    path: Path | str,
    sheets: dict[str, pd.DataFrame],
    french_labels: dict[str, str],
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="xlsxwriter", datetime_format="dd/mm/yyyy") as writer:
        for requested_name, frame in sheets.items():
            sheet_name = _safe_sheet_name(requested_name)
            output = frame.rename(columns=french_labels or {})
            output.to_excel(writer, sheet_name=sheet_name, index=False)
            worksheet = writer.sheets[sheet_name]
            worksheet.freeze_panes(1, 0)
            if len(output.columns):
                worksheet.autofilter(0, 0, max(len(output), 1), len(output.columns) - 1)
            for index, column in enumerate(output.columns):
                sample = output[column].astype("string").head(200)
                width = max(len(str(column)), *(len(str(v)) for v in sample.dropna().tolist()), 8)
                worksheet.set_column(index, index, min(width + 2, 40))
    return path
