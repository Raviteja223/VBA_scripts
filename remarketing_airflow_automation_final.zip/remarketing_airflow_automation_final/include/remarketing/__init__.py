"""Remarketing Excel automation package."""

from .pipeline import ProcessingResult, process_workbook

__all__ = ["ProcessingResult", "process_workbook"]
