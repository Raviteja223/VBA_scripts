from __future__ import annotations

from typing import Any
import unicodedata

import pandas as pd

from .data_validation import resolve_actual_column


def canonical_text(value: Any):
    if pd.isna(value):
        return pd.NA
    text = unicodedata.normalize("NFKC", str(value))
    text = text.replace("\xa0", " ").replace("\u200b", "").replace("\ufeff", "")
    return " ".join(text.split()).strip()


def canonical_key(value: Any):
    text = canonical_text(value)
    if pd.isna(text):
        return pd.NA
    return str(text).casefold()


def standardize(df: pd.DataFrame, text_columns: list[str]) -> pd.DataFrame:
    result = df.copy()
    for configured in text_columns:
        actual = resolve_actual_column(result, configured)
        result[actual] = result[actual].map(canonical_text).astype("string")
    return result
