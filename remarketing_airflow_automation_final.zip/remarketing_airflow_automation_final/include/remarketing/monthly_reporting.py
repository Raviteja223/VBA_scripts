from __future__ import annotations

import pandas as pd


def monthly_metrics(
    df: pd.DataFrame,
    date_col: str,
    value_cols: list[str],
    period: str,
) -> pd.DataFrame:
    dates = pd.to_datetime(df[date_col], errors="coerce")
    target = pd.Period(period, freq="M")
    subset = df.loc[dates.dt.to_period("M").eq(target)].copy()
    row = {"reporting_period": period, "record_count": int(len(subset))}
    for column in value_cols:
        if column not in subset.columns:
            raise KeyError(f"Monthly value column {column!r} does not exist.")
        row[f"{column}_sum"] = pd.to_numeric(subset[column], errors="coerce").sum(min_count=1)
    return pd.DataFrame([row])
