from __future__ import annotations

import pandas as pd

from .data_validation import resolve_actual_column
from .exceptions import DataValidationError


def left_lookup(
    df: pd.DataFrame,
    ref: pd.DataFrame,
    left_key: str,
    right_key: str,
    value_columns: list[str],
    required: bool = False,
) -> pd.DataFrame:
    left_actual = resolve_actual_column(df, left_key)
    right_actual = resolve_actual_column(ref, right_key)
    values_actual = [resolve_actual_column(ref, column) for column in value_columns]

    if ref.duplicated(subset=[right_actual], keep=False).any():
        raise DataValidationError(f"Reference lookup key {right_key!r} is not unique.")

    ref_subset = ref[[right_actual, *values_actual]].copy()
    if right_actual != left_actual:
        ref_subset = ref_subset.rename(columns={right_actual: left_actual})

    conflicts = [column for column in values_actual if column in df.columns and column != left_actual]
    if conflicts:
        raise DataValidationError(
            "Lookup would overwrite existing column(s): " + ", ".join(conflicts)
        )

    before = len(df)
    result = df.merge(ref_subset, on=left_actual, how="left", validate="m:1")
    if len(result) != before:
        raise DataValidationError("Reference lookup changed row count unexpectedly.")

    if required and values_actual:
        missing = result[values_actual].isna().all(axis=1)
        if missing.any():
            raise DataValidationError(
                f"Required reference lookup failed for {int(missing.sum())} row(s)."
            )
    return result
