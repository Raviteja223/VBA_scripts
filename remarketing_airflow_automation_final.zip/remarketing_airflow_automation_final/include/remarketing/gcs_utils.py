from __future__ import annotations

from pathlib import Path


def parse_gs_uri(uri: str) -> tuple[str, str]:
    if not uri.startswith("gs://"):
        raise ValueError(f"Not a GCS URI: {uri}")
    remainder = uri[5:]
    bucket, separator, blob = remainder.partition("/")
    if not bucket or not separator or not blob:
        raise ValueError(f"GCS URI must include bucket and object: {uri}")
    return bucket, blob


def _client():
    from google.cloud import storage

    return storage.Client()


def download_gcs_file(uri: str, destination: Path | str) -> Path:
    bucket_name, blob_name = parse_gs_uri(uri)
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    blob = _client().bucket(bucket_name).blob(blob_name)
    blob.download_to_filename(str(destination))
    return destination


def upload_gcs_file(source: Path | str, uri: str) -> str:
    bucket_name, blob_name = parse_gs_uri(uri)
    _client().bucket(bucket_name).blob(blob_name).upload_from_filename(str(source))
    return uri


def copy_gcs_object(source_uri: str, destination_uri: str) -> str:
    source_bucket_name, source_blob_name = parse_gs_uri(source_uri)
    destination_bucket_name, destination_blob_name = parse_gs_uri(destination_uri)
    client = _client()
    source_bucket = client.bucket(source_bucket_name)
    source_blob = source_bucket.blob(source_blob_name)
    destination_bucket = client.bucket(destination_bucket_name)
    source_bucket.copy_blob(source_blob, destination_bucket, destination_blob_name)
    return destination_uri


def blob_exists(uri: str) -> bool:
    bucket_name, blob_name = parse_gs_uri(uri)
    return _client().bucket(bucket_name).blob(blob_name).exists()
