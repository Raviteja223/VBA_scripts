from __future__ import annotations

import pandas as pd


def ytd_slice(df: pd.DataFrame, date_col: str, period: str) -> pd.DataFrame:
    dates = pd.to_datetime(df[date_col], errors="coerce")
    target = pd.Period(period, freq="M")
    start = pd.Timestamp(year=target.year, month=1, day=1)
    end = target.end_time
    mask = dates.ge(start) & dates.le(end)
    return df.loc[mask].copy()


def rebuild_periods(corrected_period: str, current_period: str) -> list[str]:
    start = pd.Period(corrected_period, freq="M")
    end = pd.Period(current_period, freq="M")
    if start > end:
        raise ValueError("corrected_period cannot be after current_period.")
    return [str(period) for period in pd.period_range(start, end, freq="M")]
