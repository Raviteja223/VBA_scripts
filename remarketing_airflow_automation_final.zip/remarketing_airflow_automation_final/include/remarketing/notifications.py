import logging

LOGGER = logging.getLogger(__name__)


def notify_success(message: str, context: dict | None = None) -> None:
    LOGGER.info("%s | context=%s", message, context or {})


def notify_failure(message: str, context: dict | None = None) -> None:
    LOGGER.error("%s | context=%s", message, context or {})
