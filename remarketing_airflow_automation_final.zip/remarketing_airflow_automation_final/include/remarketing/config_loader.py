from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .exceptions import ConfigurationError


CONFIG_FILES = {
    "workbook_config": "workbook_config.yaml",
    "business_rules": "business_rules.yaml",
    "column_mapping": "column_mapping.yaml",
    "report_config": "report_config.yaml",
}


def load_yaml(path: Path | str) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"Configuration file not found: {path}")
    with path.open("r", encoding="utf-8-sig") as handle:
        data = yaml.safe_load(handle)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ConfigurationError(f"Configuration file must contain a YAML mapping: {path}")
    return data


def load_project_configs(config_dir: Path | str) -> dict[str, dict[str, Any]]:
    config_dir = Path(config_dir)
    result: dict[str, dict[str, Any]] = {}
    for key, filename in CONFIG_FILES.items():
        result[key] = load_yaml(config_dir / filename)
    return result
