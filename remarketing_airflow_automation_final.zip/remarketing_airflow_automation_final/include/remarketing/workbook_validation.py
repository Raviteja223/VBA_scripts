from __future__ import annotations

from pathlib import Path

from .excel_reader import normalize_header, sheet_names
from .exceptions import WorkbookValidationError


def validate_workbook(
    path: Path | str,
    required_sheets: list[str],
    max_bytes: int,
) -> dict:
    path = Path(path)
    if not path.exists():
        raise WorkbookValidationError(f"Workbook not found: {path}")
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise WorkbookValidationError(f"Unsupported workbook type: {path.suffix}")
    size = path.stat().st_size
    if max_bytes and size > int(max_bytes):
        raise WorkbookValidationError(
            f"Workbook size {size} exceeds configured maximum {max_bytes} bytes."
        )
    sheets = sheet_names(path)
    normalized = {normalize_header(sheet).casefold(): sheet for sheet in sheets}
    missing = [
        sheet
        for sheet in required_sheets
        if normalize_header(sheet).casefold() not in normalized
    ]
    if missing:
        raise WorkbookValidationError(
            "Required worksheet(s) missing: " + ", ".join(missing)
        )
    return {"sheets": sheets, "bytes": size}
