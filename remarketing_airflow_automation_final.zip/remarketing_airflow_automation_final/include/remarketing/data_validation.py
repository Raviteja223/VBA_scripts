from __future__ import annotations

from typing import Any
import unicodedata

import pandas as pd

from .exceptions import DataValidationError


def normalize_column_key(value: Any) -> str:
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value))
    text = (
        text.replace("\xa0", " ")
        .replace("\u2007", " ")
        .replace("\u202f", " ")
        .replace("\u200b", "")
        .replace("\u200c", "")
        .replace("\u200d", "")
        .replace("\ufeff", "")
    )
    return " ".join(text.split()).strip().casefold()


def build_column_lookup(df: pd.DataFrame) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for column in df.columns:
        actual = str(column)
        key = normalize_column_key(actual)
        if key in lookup and lookup[key] != actual:
            raise DataValidationError(
                f"Ambiguous source columns after normalization: {lookup[key]!r} and {actual!r}"
            )
        lookup[key] = actual
    return lookup


def resolve_actual_column(df: pd.DataFrame, configured_name: str) -> str:
    lookup = build_column_lookup(df)
    actual = lookup.get(normalize_column_key(configured_name))
    if actual is None:
        raise KeyError(f"Configured source column {configured_name!r} does not exist.")
    return actual


def validate_required_columns(df: pd.DataFrame, configured_columns: list[str]) -> dict[str, str]:
    lookup = build_column_lookup(df)
    missing: list[str] = []
    resolved: dict[str, str] = {}
    seen: set[str] = set()
    for configured in configured_columns:
        if not configured:
            continue
        key = normalize_column_key(configured)
        if key in seen:
            continue
        seen.add(key)
        actual = lookup.get(key)
        if actual is None:
            missing.append(configured)
        else:
            resolved[configured] = actual
    if missing:
        raise KeyError(
            "Required SOURCE column(s) missing from the processing sheet: "
            + ", ".join(missing)
        )
    return resolved


def split_valid_invalid_rows(
    df: pd.DataFrame,
    mandatory_fields: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not mandatory_fields:
        return df.copy(), df.iloc[0:0].copy()
    resolved = [resolve_actual_column(df, field) for field in mandatory_fields]
    invalid_mask = pd.Series(False, index=df.index)
    for column in resolved:
        series = df[column]
        invalid_mask |= series.isna() | series.astype("string").str.strip().eq("")
    return df.loc[~invalid_mask].copy(), df.loc[invalid_mask].copy()


def validate_business_keys(
    df: pd.DataFrame,
    keys: list[str],
    *,
    enforce_unique: bool = False,
) -> dict[str, int]:
    if not keys:
        return {"null_key_rows": 0, "duplicate_key_rows": 0}
    resolved = [resolve_actual_column(df, key) for key in keys]
    null_mask = df[resolved].isna().any(axis=1)
    duplicate_mask = df.duplicated(subset=resolved, keep=False)
    if null_mask.any():
        raise DataValidationError(
            f"Business key contains null values in {int(null_mask.sum())} row(s)."
        )
    if enforce_unique and duplicate_mask.any():
        raise DataValidationError(
            f"Business key is duplicated in {int(duplicate_mask.sum())} row(s)."
        )
    return {
        "null_key_rows": int(null_mask.sum()),
        "duplicate_key_rows": int(duplicate_mask.sum()),
    }
