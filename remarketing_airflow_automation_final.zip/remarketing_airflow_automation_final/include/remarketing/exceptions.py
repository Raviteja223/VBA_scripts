class RemarketingError(Exception):
    """Base exception for the remarketing automation."""


class ConfigurationError(RemarketingError):
    """Raised when project configuration is invalid."""


class WorkbookValidationError(RemarketingError):
    """Raised when an input workbook is structurally invalid."""


class DataValidationError(RemarketingError):
    """Raised when source data does not satisfy configured rules."""


class ReconciliationError(RemarketingError):
    """Raised when report reconciliation fails."""
