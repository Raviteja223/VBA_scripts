import pandas as pd

from include.remarketing.reconciliation import reconcile


def test_reconcile_confirms_source_equals_valid_plus_excluded():
    source = pd.DataFrame({"x": [1, 2, 3]})
    valid = pd.DataFrame({"x": [1, 2]})
    excluded = pd.DataFrame({"x": [3]})
    result = reconcile(source, valid, excluded)
    assert result["source_count"] == 3
    assert result["valid_count"] == 2
    assert result["excluded_count"] == 1
    assert result["source_equals_valid_plus_excluded"] is True
