import pandas as pd
import pytest

from include.remarketing.excel_reader import normalize_header, _normalize_dataframe_columns


def test_normalize_header_handles_excel_unicode_and_spacing():
    assert normalize_header(" Statut ") == "Statut"
    assert normalize_header("Statut\u200b") == "Statut"
    assert normalize_header("Date\xa0de retour") == "Date de retour"
    assert normalize_header("Date   de   retour") == "Date de retour"


def test_dataframe_headers_are_normalized():
    df = pd.DataFrame(columns=["Statut\u200b", "Date\xa0de retour", " Vendeur "])
    result = _normalize_dataframe_columns(df)
    assert result.columns.tolist() == ["Statut", "Date de retour", "Vendeur"]


def test_duplicate_headers_created_by_normalization_are_rejected():
    df = pd.DataFrame(columns=["Statut", " Statut "])
    with pytest.raises(ValueError, match="Duplicate Excel column names"):
        _normalize_dataframe_columns(df)
