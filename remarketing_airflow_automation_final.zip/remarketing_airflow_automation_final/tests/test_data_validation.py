import pandas as pd
import pytest

from include.remarketing.data_validation import resolve_actual_column, validate_required_columns


def test_resolve_actual_column_is_case_and_whitespace_tolerant():
    df = pd.DataFrame(columns=["Contrat", "Date de retour", "Vendeur"])
    assert resolve_actual_column(df, " contrat ") == "Contrat"
    assert resolve_actual_column(df, "DATE DE RETOUR") == "Date de retour"


def test_validate_required_columns_reports_all_missing_columns():
    df = pd.DataFrame(columns=["VIN", "Statut"])
    with pytest.raises(KeyError) as exc:
        validate_required_columns(df, ["VIN", "Contrat", "Date de retour"])
    message = str(exc.value)
    assert "Contrat" in message
    assert "Date de retour" in message
