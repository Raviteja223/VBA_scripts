from pathlib import Path

import pandas as pd

from include.remarketing.pipeline import process_workbook


def test_process_workbook_end_to_end(tmp_path: Path):
    input_path = tmp_path / "input.xlsx"
    output_path = tmp_path / "output.xlsx"

    source = pd.DataFrame(
        {
            "Contrat": ["C1", "C2"],
            "VIN": ["V1", "V2"],
            "Statut": ["Solde", "Autre"],
            "Date de retour": pd.to_datetime(["2026-07-01", "2026-07-05"]),
            "date vente": pd.to_datetime(["2026-07-10", None]),
            "Vendeur": ["A", "B"],
            "Model": ["M1", "M2"],
        }
    )
    with pd.ExcelWriter(input_path, engine="xlsxwriter") as writer:
        source.to_excel(writer, sheet_name="Remarketing", index=False)

    configs = {
        "workbook_config": {
            "max_bytes": 250000000,
            "required_sheets": ["Remarketing"],
            "source_sheet": "Remarketing",
            "required_columns": ["Contrat", "VIN"],
            "business_keys": ["Contrat"],
            "enforce_unique_business_keys": False,
            "text_columns": ["Contrat", "Statut", "Vendeur", "Model"],
            "mandatory_fields": [],
            "output": {
                "detail_sheet": "Remarketing",
                "remarketing_sheet": "Rapport Remarketing",
                "era_sheet": "Rapport ERA",
            },
        },
        "business_rules": {
            "columns": {
                "status_raw": "Statut",
                "status": "Statut calculé",
                "event_date": "Date de retour",
                "settlement_date": "date vente",
                "age_days": "Âge inventaire (jours)",
                "age_bucket": "Tranche Âge",
                "return_date": "Date de retour",
                "return_month": "Mois de retour",
                "return_year": "Année de Retour",
            },
            "aging_buckets": [30, 60, 90, 120, 150, 180, 360],
        },
        "column_mapping": {"french_labels": {}},
        "report_config": {"value_columns": [], "pivots": []},
    }

    result = process_workbook(input_path, output_path, configs, "2026-07")
    assert output_path.exists()
    assert result.source_count == 2
    assert result.valid_count == 2
    assert result.reconciliation["source_equals_valid_plus_excluded"] is True

    xls = pd.ExcelFile(output_path)
    assert "Remarketing" in xls.sheet_names
    assert "Rapport Remarketing" in xls.sheet_names
    assert "Rapport ERA" in xls.sheet_names
