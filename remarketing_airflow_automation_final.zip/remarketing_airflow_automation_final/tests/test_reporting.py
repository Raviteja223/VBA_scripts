import pandas as pd

from include.remarketing.monthly_reporting import monthly_metrics
from include.remarketing.ytd_reporting import rebuild_periods, ytd_slice


def _data():
    return pd.DataFrame(
        {
            "Date de retour": pd.to_datetime(["2026-01-10", "2026-07-05", "2026-07-20", "2025-07-01"]),
            "Valeur": [10, 20, 30, 999],
        }
    )


def test_monthly_metrics_filters_exact_period_and_sums_values():
    result = monthly_metrics(_data(), "Date de retour", ["Valeur"], "2026-07")
    assert result.loc[0, "record_count"] == 2
    assert result.loc[0, "Valeur_sum"] == 50


def test_ytd_slice_returns_only_current_year_through_period():
    result = ytd_slice(_data(), "Date de retour", "2026-07")
    assert len(result) == 3
    assert result["Valeur"].sum() == 60


def test_rebuild_periods_is_inclusive():
    assert rebuild_periods("2026-02", "2026-05") == ["2026-02", "2026-03", "2026-04", "2026-05"]
