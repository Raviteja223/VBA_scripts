import pandas as pd

from include.remarketing.calculations import (
    age_bucket,
    apply_rules,
    inventory_age_days,
    inventory_status,
)


def test_inventory_age_days_handles_missing_status():
    status = pd.Series(["Solde", pd.NA, "Non Solde"], dtype="string")
    event = pd.Series(pd.to_datetime(["2026-07-01", "2026-07-01", "2026-07-01"]))
    settlement = pd.Series(pd.to_datetime(["2026-07-10", None, None]))

    result = inventory_age_days(status, event, settlement, "2026-07-31")

    assert result.iloc[0] == 9
    assert pd.isna(result.iloc[1])
    assert result.iloc[2] == 30


def test_inventory_status_preserves_missing_and_classifies_values():
    raw = pd.Series(["Solde", "Autre", pd.NA], dtype="string")
    result = inventory_status(raw)
    assert result.tolist()[:2] == ["Solde", "Non Solde"]
    assert pd.isna(result.iloc[2])


def test_age_bucket_uses_configured_thresholds():
    days = pd.Series([0, 30, 31, 60, 61, 361, pd.NA], dtype="Float64")
    result = age_bucket(days, [30, 60, 360])
    assert result.iloc[0] == "<= 30"
    assert result.iloc[2] == "31-60"
    assert result.iloc[4] == "61-360"
    assert result.iloc[5] == "> 360"
    assert pd.isna(result.iloc[6])


def test_apply_rules_creates_expected_derived_columns():
    df = pd.DataFrame(
        {
            "Statut": pd.Series(["Solde", "Autre"], dtype="string"),
            "Date de retour": pd.to_datetime(["2026-07-01", "2026-07-01"]),
            "date vente": pd.to_datetime(["2026-07-10", None]),
        }
    )
    cfg = {
        "columns": {
            "status_raw": "Statut",
            "status": "Statut calculé",
            "event_date": "Date de retour",
            "settlement_date": "date vente",
            "age_days": "Âge inventaire (jours)",
            "age_bucket": "Tranche Âge",
            "return_date": "Date de retour",
            "return_month": "Mois de retour",
            "return_year": "Année de Retour",
        },
        "aging_buckets": [30, 60, 90],
    }
    out = apply_rules(df, cfg, "2026-07")
    assert "Statut calculé" in out.columns
    assert "Âge inventaire (jours)" in out.columns
    assert "Tranche Âge" in out.columns
    assert "Mois de retour" in out.columns
    assert "Année de Retour" in out.columns
    assert out.loc[0, "Âge inventaire (jours)"] == 9
    assert out.loc[1, "Âge inventaire (jours)"] == 30
