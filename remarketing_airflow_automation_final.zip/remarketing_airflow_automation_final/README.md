# Remarketing Airflow Automation

This project automates the Excel-based remarketing/repossessions workflow using Python and Airflow/Astronomer. The source workbook remains unchanged; the pipeline reads it and creates a separate report workbook.

## Project layout

```text
config/                     YAML configuration
dags/                       Airflow DAGs
include/remarketing/        Reusable processing package
scripts/run_local.py        Local end-to-end runner
scripts/audit_schema.py     One-shot schema/config audit
tests/                      Unit and end-to-end synthetic tests
local_test/input/           Put one copied XLSX here
local_test/output/          Generated local report
BUSINESS_RULES.md           Current interpreted rules
OPEN_QUESTIONS.md           Rules still requiring business confirmation
```

## Local setup

From the project root on Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Copy the test workbook into `local_test/input/`. Keep one `.xlsx` file there.

Run the schema audit first:

```powershell
python -m scripts.audit_schema
```

For the July 2026 workbook:

```powershell
$env:TEST_PERIOD="2026-07"
python -m scripts.run_local
```

The generated file is:

```text
local_test/output/remarketing_report_local_test.xlsx
```

You can also provide explicit paths:

```powershell
$env:LOCAL_INPUT_FILE="C:\path\to\copy.xlsx"
$env:LOCAL_OUTPUT_FILE="C:\path\to\result.xlsx"
$env:TEST_PERIOD="2026-07"
python -m scripts.run_local
```

## Tests

```powershell
pytest -v
```

## Airflow/Astronomer

`remarketing_file_watcher` is intentionally `schedule=None`. A GCS event integration outside the DAG should call the Airflow API and trigger it with:

```json
{
  "bucket": "your-bucket",
  "object_name": "incoming/file.xlsx",
  "generation": "optional-generation",
  "period": "2026-07"
}
```

The watcher validates metadata and triggers `remarketing_processing`. The processing DAG downloads the exact object, creates a raw GCS copy, processes the workbook in one worker task, uploads the report, and writes an audit JSON object. This avoids passing DataFrames or workbook bytes through XCom.

The GCP identity used by Airflow must be able to read the incoming object and write to the `raw/`, `reports/`, and `audit/` prefixes.

## Important business-rule status

The code is technically runnable, but production acceptance still requires reconciliation against the analyst's manual output. See `BUSINESS_RULES.md` and `OPEN_QUESTIONS.md` before treating the generated monthly/YTD reports as final client logic.
